# AFL starting test cases

  (See [../README.md](../README.md) for the general instruction manual.)

The archives/, images/, multimedia/, and others/ subdirectories contain small,
standalone files that can be used to seed afl-fuzz when testing parsers for a
variety of common data formats.

There is probably not much to be said about these files, except that they were
optimized for size and stripped of any non-essential fluff. Some directories
contain several examples that exercise various features of the underlying format.
For example, there is a PNG file with and without a color profile.

Additional test cases are always welcome.

In addition to well-chosen starting files, many fuzzing jobs benefit from a
small and concise dictionary. See [../dictionaries/README.md](../dictionaries/README.md) for more.
