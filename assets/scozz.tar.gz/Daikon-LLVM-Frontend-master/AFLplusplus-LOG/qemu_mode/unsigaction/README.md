# unsigaction

This library disables sigaction handlers when preloaded.

Mainly needed by Wine mode but can be used as a separate tool.

A similar solution can be found in [preeny](https://github.com/zardus/preeny).
