SELECT fts3_tokenizer(@0());
