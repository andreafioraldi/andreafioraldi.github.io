import sys
import os
import re
import ast
import json
import argparse

abort_mode = False

INT_RE = re.compile(r"^[-+]?[0-9]+$")
FLOAT_RE = re.compile("^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$")

BIN_OPS = ("==", "!=", ">", "<", ">=", "<=")
GT_CMP_OPS = (">", ">=")
LT_CMP_OPS = ("<", "<=")

OPERATORS = ("+", "-", "*", "/", "%", "&", "|", "^", "~", "==", "!=", ">", "<", ">=", "<=")

CMP_MAX_OPS = ("!=", "<", ">", ">=", "<=")

code = []
fnid = 0
max_id = 0
set_id = 0

specs = {}

blacklist = {}
var_types = {}

def next_power_of_2(x):  
    return 1 if x == 0 else 2**(x - 1).bit_length()

def is_int(x):
    return re.match(INT_RE, x) or (x[-1] == "L" and re.match(INT_RE, x[:-1]))

def is_float(x):
    return re.match(FLOAT_RE, x)

def is_ident(x):
    if len(x) == 0: return False
    if x[0] in "1234567890": return False
    for c in x:
        if c not in "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890_.:<>":
            return False
    return True

def get_c_type(t):
    base_types = {"i8": "int8_t", "i16": "int16_t", "i32": "int32_t",
                  "i64": "int64_t", "float": "float", "double": "double"}
    if t in base_types:
        return base_types[t]
    return "uintptr_t"


def is_in_blacklist(v, bl):
    n = v
    if n.startswith("orig("):
        n = v[len("orig("):v.find(")")]
        if n in bl: return True
    if n.startswith("ORIG:"):
        n = v[len("ORIG:"):]
        if n in bl: return True
    return n in bl

def parse_inv(funcname, ppt, inv):
    global code, fnid, max_id, set_id, blacklist, var_types
    if len(inv) < 2:
        return
    bl = []
    if funcname in blacklist and ppt in blacklist[funcname]:
        bl = blacklist[funcname][ppt]
    if ppt == "EXIT" and ppt not in var_types[funcname]:
        types = var_types[funcname]["EXIT0"]
    else:
        types = var_types[funcname][ppt]
    
    if len(inv) >= 5 and inv[1] == "one" and inv[2] == "of" and inv[3] == "{" and inv[-1] == "}":
        x = inv[0]
        if x.startswith("orig("):
            x = x[len("orig("):x.find(")")]
            x = "ORIG:" + x
        if not is_ident(x):
            return
        t = get_c_type(types[x.replace("ORIG:", "")])
        nums = "".join(inv[4: -1]).split(",")
        cnt = 0
        checks = []
        for n in nums:
            n = n.strip()
            if re.match(FLOAT_RE, n) is None and not is_int(n):
                return
            if n.endswith("L"):
                n = n[:-1] + "LL"
            n = "(%s)" % t + n
            checks.append("v0 == " + n)
        return " || ".join(checks), [(t, x)]
    
    numvars = 0
    variables = []
    parsed = []
    for x in inv:
        pow2 = False
        if x.endswith("**2"):
            pow2 = True
            x = x[:-3]
        if x == "null":
            x = "0"
        if x.startswith("orig("):
            x = x[len("orig("):x.find(")")]
            x = "ORIG:" + x
        if is_int(x):
            if "L" in x: x = x[:-1]
            parsed += [x + "LL"]
        elif is_float(x):
            parsed += [x]
        elif x in OPERATORS:
            parsed += [x]
        elif is_ident(x):
            if is_in_blacklist(x, bl):
                return
            if pow2:
                parsed += ["v%d * v%d" % (numvars, numvars)]
            else:
                parsed += ["v%d" % numvars]
            numvars += 1
            if x.replace("ORIG:", "") not in types:
                return
            t = get_c_type(types[x.replace("ORIG:", "")])
            #if t == "uintptr_t": # TODO should we hadle pointer constraints?
            #    return
            variables += [(t, x)]
        else:
            return
    #print(" ".join(parsed), variables)
    return " ".join(parsed), variables

def add_to_spec(funcname, ppt, invd):
    global specs
    specs[funcname] = specs.get(funcname, {})
    specs[funcname][ppt] = specs[funcname].get(ppt, {})
    specs[funcname][ppt]["vars"] = specs[funcname][ppt].get("vars", [])
    specs[funcname][ppt]["parents"] = specs[funcname][ppt].get("parents", [])
    specs[funcname][ppt]["constrs"] = specs[funcname][ppt].get("constrs", [])
    for v in invd["vars"]:
        if v not in specs[funcname][ppt]["vars"]:
            p = ""
            for s in v.split(".")[:-1]:
                p += s
                if p not in specs[funcname][ppt]["parents"]:
                    specs[funcname][ppt]["parents"].append(p)
                p += "."
            specs[funcname][ppt]["vars"].append(v)
    specs[funcname][ppt]["constrs"].append(invd)

def process_invariant(funcname, ppt, inv):
    global code, fnid, max_id, set_id, blacklist
    parsed = parse_inv(funcname, ppt, inv)
    if parsed is None:
        return
    constr, variables = parsed
    bl = []
    if funcname in blacklist and ppt in blacklist[funcname]:
        bl = blacklist[funcname][ppt]
    for v in variables:
        p = ""
        for s in v[1].split(".")[:-1]:
            p += s
            if p.replace("ORIG:", "") in bl:
                return
            p += "."
    params = []
    fmtvals = []
    i = 0
    for v in variables:
        params.append("%s v%s" % (v[0], i))
        fmtvals.append("(long long)(v%d)" % i)
        i += 1
    params = ", ".join(params)
    fmt = "\"(" + ("%lld, " * len(fmtvals))[:-2] + ")\""
    fmtvals = ", ".join(fmtvals)
    add_to_spec(funcname, ppt, {"type": len(variables), "vars": list(map(lambda x: x[1], variables)), "func": "__daikon_constr_%d" % fnid})
    code += [
"""
void __daikon_constr_%d(%s) {
  HANDLE_CONSTR(%d, %s, \"%s\", %s, %s);
}
""" % (fnid, params, fnid, constr, funcname + "[" + ppt + "]: " + " ".join(inv), fmt, fmtvals)]
    fnid += 1
    

def add_to_spec__OLD(funcname, ppt, invd, bl):
    global specs, blacklist
    specs[funcname] = specs.get(funcname, {})
    specs[funcname][ppt] = specs[funcname].get(ppt, {})
    specs[funcname][ppt]["vars"] = specs[funcname][ppt].get("vars", [])
    specs[funcname][ppt]["parents"] = specs[funcname][ppt].get("parents", [])
    specs[funcname][ppt]["constrs"] = specs[funcname][ppt].get("constrs", [])
    if invd["v0"] not in specs[funcname][ppt]["vars"]:
        p = ""
        for s in invd["v0"].split(".")[:-1]:
            p += s
            if p.replace("ORIG:", "") in bl:
                return False
            if p not in specs[funcname][ppt]["parents"]:
                specs[funcname][ppt]["parents"].append(p)
            p += "."
        specs[funcname][ppt]["vars"].append(invd["v0"])
    if "v1" in invd:
        if invd["v1"] not in specs[funcname][ppt]["vars"]:
            p = ""
            for s in invd["v1"].split(".")[:-1]:
                p += s
                if p.replace("ORIG:", "") in bl:
                    return False
                if p not in specs[funcname][ppt]["parents"]:
                    specs[funcname][ppt]["parents"].append(p)
                p += "."
        specs[funcname][ppt]["vars"].append(invd["v1"])
    specs[funcname][ppt]["constrs"].append(invd)
    return True


def process_invariant__OLD(funcname, ppt, inv):
    global code, fnid, max_id, set_id, blacklist
    if len(inv) < 2:
        return
    #if ppt != "ENTER": return
    if "###loop" in funcname and ppt != "ENTER":
        return
    bl = []
    if funcname in blacklist and ppt in blacklist[funcname]:
        bl = blacklist[funcname][ppt]
    if inv[0].startswith("orig("):
        n = inv[0][len("orig("):inv[0].find(")")]
        if n in bl: return
        inv[0] = "ORIG:" + n
    elif inv[0] in bl:
        return
    if ppt == "EXIT" and ppt not in var_types[funcname]:
        types = var_types[funcname]["EXIT0"]
    else:
        types = var_types[funcname][ppt]
    if inv[1] in BIN_OPS and len(inv) == 3:
        if re.match(FLOAT_RE, inv[2]) or inv[2] == "null" or is_int(inv[2]):
            if inv[2] == "null":
                inv[2] = "0"
            a0_type = get_c_type(types[inv[0].replace("ORIG:", "")])
            if a0_type == "uintptr_t":
                return
            if add_to_spec(funcname, ppt, {"type": 1, "v0": inv[0], "func": "__daikon_constr_%d" % fnid}, bl):
                n = inv[2]
                if n.endswith("L"):
                    n = n[:-1]
                if is_int(n) and a0_type == "int64_t":
                    n = n + "LL"
                n = "(%s)" % a0_type + n
                if False and inv[1] in CMP_MAX_OPS and a0_type.startswith("int"):
                    cmp_n = n
                    if inv[1] == ">=":
                        # a >= 1 --> a > 0
                        cmp_n = n + "-1"
                    elif inv[1] == "<=":
                        # a <= 1 --> a < 2
                        cmp_n = n + "+1"
                    code += [
"""
void __daikon_constr_%d(%s a0) { // cost binop
  HANDLE_CONSTR_CMP1(%d, a0, %s, (a0 %s %s), \"%s\", a0);
}
""" % (fnid, a0_type, fnid, cmp_n, inv[1], n, funcname + "[" + ppt + "]: " + " ".join(inv))]
                else:
                    code += [
"""
void __daikon_constr_%d(%s a0) { // cost binop
  HANDLE_CONSTR1(%d, (a0 %s %s), \"%s\", a0);
}
""" % (fnid, a0_type, fnid, inv[1], n, funcname + "[" + ppt + "]: " + " ".join(inv))]
                fnid += 1
        else:
            if inv[2].startswith("orig("):
                n = inv[2][len("orig("):inv[2].find(")")]
                if n in bl: return
                inv[2] = "ORIG:" + n
            elif inv[2] in bl:
                return
            a1_val = "a1"
            if inv[2].endswith("**2"):
                a1_val = "a1 * a1"
                inv[2] = inv[2][:-3]
            a0_type = get_c_type(types[inv[0].replace("ORIG:", "")])
            a1_type = get_c_type(types[inv[2].replace("ORIG:", "")])
            # here uintptr_t is ok
            if add_to_spec(funcname, ppt, {"type": 2, "v0": inv[0], "v1": inv[2], "func": "__daikon_constr_%d" % fnid}, bl):
                if False and inv[1] in CMP_MAX_OPS and a0_type.startswith("int") and a1_type.startswith("int"):
                    cmp_a1 = a1_val
                    if inv[1] == ">=":
                        # a >= 1 --> a > 0
                        cmp_a1 += "-1"
                    elif inv[1] == "<=":
                        # a <= 1 --> a < 2
                        cmp_a1 += "+1"
                    code += [
"""
void __daikon_constr_%d(%s a0, %s a1) { // binop
  HANDLE_CONSTR_CMP2(%d, a0, %s, (a0 %s %s), \"%s\", a0, %s);
}
""" % (fnid, a0_type, a1_type, fnid, cmp_a1, inv[1], a1_val, funcname + "[" + ppt + "]: " + " ".join(inv), a1_val)]
                else:
                    code += [
"""
void __daikon_constr_%d(%s a0, %s a1) { // binop
  HANDLE_CONSTR2(%d, (a0 %s a1), \"%s\", a0, %s);
}
""" % (fnid, a0_type, a1_type, fnid, inv[1], funcname + "[" + ppt + "]: " + " ".join(inv), a1_val)]
                fnid += 1

    if len(inv) >= 5 and inv[1] == "one" and inv[2] == "of" and inv[3] == "{" and inv[-1] == "}":
        a0_type = get_c_type(types[inv[0].replace("ORIG:", "")])
        if a0_type == "uintptr_t":
            return
        nums = "".join(inv[4: -1]).split(",")
        cnt = 0
        checks = []
        for n in nums:
            n = n.strip()
            if re.match(FLOAT_RE, n) is None and not is_int(n):
                return
            if n.endswith("L"):
                n = n[:-1]
            if is_int(n) and a0_type == "int64_t":
                n = n + "LL"
            n = "(%s)" % a0_type + n
            checks.append("a0 == " + n)
        if add_to_spec(funcname, ppt, {"type": 1, "v0": inv[0], "func": "__daikon_constr_%d" % fnid}, bl):
            code += [
"""
void __daikon_constr_%d(%s a0) { // one of
  HANDLE_CONSTR1(%d, %s, \"%s\", a0);
}
""" % (fnid, a0_type, fnid, " || ".join(checks), funcname + "[" + ppt + "]: " + " ".join(inv))]
            fnid += 1

def process_daikon_out(daikon):
    daikon = daikon.replace("Exiting Daikon.\n", "")
    daikon = daikon.split("===========================================================================\n")[1:]
    for invs in daikon:
        invs = invs.split("\n")
        funcname = invs[0].split("():::")[0]
        ppt = invs[0].split("():::")[1]
        invs = invs[1:]
        for inv in invs:
            i = inv.split()
            if len(i) == 0: continue
            process_invariant(funcname, ppt, i)

DESCR = "Reconstruct decls file"
opt = argparse.ArgumentParser(description=DESCR, formatter_class=argparse.RawTextHelpFormatter)
opt.add_argument("-i", action='store', required=True)
opt.add_argument("-b", action='store', required=True)
opt.add_argument("-l", action='store', required=True)
args = opt.parse_args()

with open(args.b) as f:
    blacklist = json.load(f)

with open(args.l) as f:
    body = f.read()
    body = ast.literal_eval(body)
    for data in body:
        var_types[data["name"]] = {}
        for ppt in data["ppts"]:
            var_types[data["name"]][ppt] = {}
            for v in data["ppts"][ppt]:
                var_types[data["name"]][ppt][v["name"]] = v["type"]

with open(args.i) as f:
    process_daikon_out(f.read())

with open("constraints.c", "w") as f:
    f.write("#include \"stdint.h\"\n")
    f.write("#include \"stdio.h\"\n")
    f.write("#include \"stdlib.h\"\n")
    f.write("#include \"assert.h\"\n")
    if abort_mode:
        f.write("""

#define HANDLE_CONSTR(id, inv, msg, fmt, ...) do { \\
 \\
  if (!(inv)) { \\
    fprintf(stderr, "VIOLATED INVARIANT: %s -- " fmt "\\n", msg, __VA_ARGS__); \\
    if (!getenv("INVS_NO_ABORT")) abort(); \\
  } \\
 \\
} while(0)

""")
    else:
        f.write("""
#define INVARIANTS_MAP_SIZE 32768

extern uint8_t *__afl_area_ptr;
extern uint32_t *__afl_invariants_count;
extern uint8_t *__afl_invariants_map;
extern uint8_t *__afl_max_map;

extern __thread uint32_t __afl_state;

#define HANDLE_CONSTR(id, inv, msg, fmt, ...) do { \\
 \\
  if (__afl_invariants_map) { \\
    if (!(inv)) { \\
   \\
      uint32_t k = (id) & (INVARIANTS_MAP_SIZE -1); \\
   \\
      if (__afl_invariants_map[k] == 0) { \\
        __afl_invariants_map[k] = 1; \\
        *__afl_invariants_count += 1; \\
      } \\
      if (__afl_invariants_map[k] != 0xff) __afl_state ^= k; \\
   \\
    } \\
  } else { \\
    if (!(inv)) \\
      fprintf(stderr, "VIOLATED INVARIANT #%d: %s -- " fmt "\\n", id, msg, __VA_ARGS__); \\
  } \\
 \\
} while(0)

""")
    f.write("".join(code) + "\n")

with open("daikon_constrs.json", "w") as f:
    json.dump(specs, f, indent=2)

