#include "llvm/IR/Function.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/PassManager.h"
#include "llvm/ADT/ArrayRef.h"
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/DepthFirstIterator.h"
#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/ADT/StringRef.h"
#include "llvm/ADT/Triple.h"
#include "llvm/ADT/Twine.h"
#include "llvm/Analysis/MemoryBuiltins.h"
#include "llvm/Analysis/TargetLibraryInfo.h"
#include "llvm/Analysis/ValueTracking.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/BinaryFormat/MachO.h"
#include "llvm/IR/Argument.h"
#include "llvm/IR/Attributes.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/CallSite.h"
#include "llvm/IR/Comdat.h"
#include "llvm/IR/Constant.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DIBuilder.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/DebugInfoMetadata.h"
#include "llvm/IR/DebugLoc.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Dominators.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/GlobalAlias.h"
#include "llvm/IR/GlobalValue.h"
#include "llvm/IR/GlobalVariable.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/InlineAsm.h"
#include "llvm/IR/InstVisitor.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Intrinsics.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/MDBuilder.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Use.h"
#include "llvm/IR/Value.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/DebugInfo.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/MC/MCSectionMachO.h"
#include "llvm/Pass.h"
#include "llvm/Support/Casting.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/ErrorHandling.h"
#include "llvm/Support/MathExtras.h"
#include "llvm/Support/ScopedPrinter.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Transforms/Instrumentation.h"
#include "llvm/Transforms/Utils/ASanStackFrameLayout.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"
#include "llvm/Transforms/Utils/Local.h"
#include "llvm/Transforms/Utils/ModuleUtils.h"
#include "llvm/Transforms/Utils/PromoteMemToReg.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <tuple>
#include <fstream>

#include "json.hpp"

#define MAX_DEPTH 3

using namespace llvm;
using json = nlohmann::json;

typedef std::map< Type*, std::set<ConstantInt*> > FieldsMap;
typedef std::map< std::string, Instruction* > VarMap;

static json* Constrs = nullptr;

static size_t TypeSizeToSizeIndex(uint32_t TypeSize) {
  size_t Res = countTrailingZeros(TypeSize / 8);
  return Res;
}

void ReplaceAll(std::string& S, std::string P, std::string R) {
	size_t pos = S.find(P);
	while(pos != std::string::npos) {
		S.replace(pos, P.size(), R);
		pos = S.find(P, pos + R.size());
	}
}

DIType* GetFieldMeta(MDNode* meta, unsigned Idx) {

  DIType* Ty;
  if (DIVariable* D = dyn_cast<DIVariable>(meta)) {
    Ty = D->getType();
  } else if (DIType* T = dyn_cast<DIType>(meta)) {
    Ty = T;
  } else return nullptr;
  
  DIType* TmpTy = Ty;
  
  // recurse typedefs
  for (unsigned i = 0; i < 128 && TmpTy->getTag() == dwarf::DW_TAG_typedef; ++i) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }

  if (TmpTy->getTag() == dwarf::DW_TAG_pointer_type) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }
  
  // recurse typedefs
  for (unsigned i = 0; i < 128 && TmpTy->getTag() == dwarf::DW_TAG_typedef; ++i) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }
  
  if (TmpTy->getTag() != dwarf::DW_TAG_structure_type)
    return nullptr;

  DINodeArray Fields = static_cast<DICompositeType*>(TmpTy)->getElements();
  if (Idx < Fields.size())
    return static_cast<DIType*>(Fields[Idx]);

  return nullptr;

}

void IRBSplitBlockAndInsertIfThenElse(IRBuilder<>& IRB, Value *Cond,
                                      Instruction *SplitBefore,
                                      Instruction **ThenTerm,
                                      Instruction **ElseTerm) {
  BasicBlock *Head = SplitBefore->getParent();
  BasicBlock *Tail = Head->splitBasicBlock(SplitBefore->getIterator());
  Instruction *HeadOldTerm = Head->getTerminator();
  LLVMContext &C = Head->getContext();
  BasicBlock *ThenBlock = BasicBlock::Create(C, "", Head->getParent(), Tail);
  BasicBlock *ElseBlock = BasicBlock::Create(C, "", Head->getParent(), Tail);
  *ThenTerm = BranchInst::Create(Tail, ThenBlock);
  (*ThenTerm)->setDebugLoc(SplitBefore->getDebugLoc());
  *ElseTerm = BranchInst::Create(Tail, ElseBlock);
  (*ElseTerm)->setDebugLoc(SplitBefore->getDebugLoc());
  BranchInst *HeadNewTerm =
   BranchInst::Create(/*ifTrue*/ThenBlock, /*ifFalse*/ElseBlock, Cond);
  ReplaceInstWithInst(HeadOldTerm, HeadNewTerm);
  IRB.SetInsertPoint(&*Tail->getFirstInsertionPt());
}

Instruction *IRBSplitBlockAndInsertIfThen(IRBuilder<>& IRB, Value *Cond,
                                          Instruction *SplitBefore,
                                          bool Unreachable = false) {
   BasicBlock *Head = SplitBefore->getParent();
   BasicBlock *Tail = Head->splitBasicBlock(SplitBefore->getIterator());
   Instruction *HeadOldTerm = Head->getTerminator();
   LLVMContext &C = Head->getContext();
   Instruction *CheckTerm;
   BasicBlock *ThenBlock = BasicBlock::Create(C, "", Head->getParent(), Tail);
   if (Unreachable)
     CheckTerm = new UnreachableInst(C, ThenBlock);
   else
     CheckTerm = BranchInst::Create(Tail, ThenBlock);
   CheckTerm->setDebugLoc(SplitBefore->getDebugLoc());
   BranchInst *HeadNewTerm =
     BranchInst::Create(/*ifTrue*/ThenBlock, /*ifFalse*/Tail, Cond);
   ReplaceInstWithInst(HeadOldTerm, HeadNewTerm);
   IRB.SetInsertPoint(&*Tail->getFirstInsertionPt());
   return CheckTerm;
}


struct DaikonInstruments {

  DaikonInstruments(Module& _M, Function &_F, LoopInfo &_LI) : M(_M), F(_F), LI(_LI) {
    initialize();
  }
  
  static bool isBlacklisted(const Function *F) {

    static const char *Blacklist[] = {

        "asan.", "llvm.", "sancov.", "__ubsan_handle_", "ign.", "__afl_",
        "_fini", "__libc_csu", "__asan",  "__msan", "msan.", "LLVMFuzzer"

    };

    for (auto const &BlacklistFunc : Blacklist) {

      if (F->getName().startswith(BlacklistFunc)) { return true; }

    }
    
    // if (F->getName() == "main") return true;
    if (F->getName() == "_start") return true;

    return false;

  }
  
  void initialize();
  bool instrumentFunction();
  
  bool visitStructure(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, Value* V, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents);
  bool visitVariable(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Value* V, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents, bool isPtr = true);

  bool iterArguments(IRBuilder<>& IRB, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents);
  
  bool isInterestingType(Type *T);
  
  Type *VoidTy, *Int8Ty, *Int16Ty, *Int32Ty, *Int64Ty, *FloatTy, *DoubleTy,
       *StructTy, *Int8PTy, *Int16PTy, *Int32PTy, *Int64PTy, *FloatPTy,
       *DoublePTy, *StructPTy, *FuncTy;
  Type *IntTypeSized[4];

  Function* dbgDeclareFn;

  GlobalVariable* AFLState;

  LLVMContext *C;
  Module& M;
  Function &F;
  LoopInfo &LI;
  int LongSize;
  
  std::string funcname;
  
  std::vector<DILocalVariable*> DbgVars;

};

void DaikonInstruments::initialize() {

  if (Constrs == nullptr) {
    std::string daikon_constrs_path = "constrs.json";
    if (getenv("DAIKON_OUTPUT_PATH"))
      daikon_constrs_path = getenv("DAIKON_OUTPUT_PATH") + std::string("/constrs.json");
    
    Constrs = new json();
  
    std::ifstream f(daikon_constrs_path);
    f >> *Constrs;
    f.close();
  }
  
  funcname = M.getModuleIdentifier() + ":" + F.getName().str();
  if (funcname.size() >= 2 && funcname[0] == '.' && funcname[1] == '/')
    funcname.erase(0, 2);
  ReplaceAll(funcname, "\\", "\\\\"); // daikon naming convention
  ReplaceAll(funcname, " ", "\\_");
  ReplaceAll(funcname, "/", "_");

  C = &(M.getContext());
  
  LongSize = M.getDataLayout().getPointerSizeInBits();

  VoidTy = Type::getVoidTy(*C);

	Int8Ty = IntegerType::get(*C, 8);
	Int16Ty = IntegerType::get(*C, 16);
	Int32Ty = IntegerType::get(*C, 32);
	Int64Ty = IntegerType::get(*C, 64);

	FloatTy = Type::getFloatTy(*C);
	DoubleTy = Type::getDoubleTy(*C);

	StructTy = StructType::create(*C);
	
	Int8PTy  = PointerType::get(Int8Ty, 0);
	Int16PTy = PointerType::get(Int16Ty, 0);
	Int32PTy = PointerType::get(Int32Ty, 0);
	Int64PTy = PointerType::get(Int64Ty, 0);

	FloatPTy = PointerType::get(FloatTy, 0);
	DoublePTy = PointerType::get(DoubleTy, 0);

	StructPTy = PointerType::get(StructTy, 0);

	FuncTy = FunctionType::get(VoidTy, true);

	dbgDeclareFn = M.getFunction("llvm.dbg.declare");
	
	IntTypeSized[0] = Int8Ty;
	IntTypeSized[1] = Int16Ty;
	IntTypeSized[2] = Int32Ty;
	IntTypeSized[3] = Int64Ty;
	
	AFLState = M.getGlobalVariable("__afl_state");
	assert (AFLState != nullptr);
	
}

bool DaikonInstruments::visitStructure(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, Value* V, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents) {

  bool FunctionModified = false;

  unsigned Idx;
  unsigned Num = ST->getNumElements();
  
  // mayeb use usedFields for structs
  
  for(Idx = 0; Idx < Num; ++Idx) {

    Type* T = ST->getElementType(Idx);
    
    if (!isInterestingType(T)) continue;
    
    std::string field_name = name + ".field" + std::to_string(Idx);
    DIType* field_meta = nullptr;
    if (meta) {
      field_meta = GetFieldMeta(meta, Idx);
      if (field_meta) {
        field_name = name + "." + field_meta->getName().str();
        field_meta = static_cast<DIDerivedType*>(field_meta)->getBaseType();
      }
    }

    Value* indexList[2] = {ConstantInt::get(Int32Ty, 0, true), ConstantInt::get(Int32Ty, Idx, true)};
    
    if(StructType *FST = dyn_cast<StructType>(T)) {
    
      Value* GEP = IRB.CreateInBoundsGEP(V, ArrayRef<Value*>(indexList, 2));
      FunctionModified |= visitVariable(IRB, field_name, field_meta, GEP, Vals, Guards, Parents, false);
      
      FunctionModified = true;

    } else if (Vals.find(name) != Vals.end() || Parents.find(name) != Parents.end()) {

      Value* GEP = IRB.CreateInBoundsGEP(V, ArrayRef<Value*>(indexList, 2));
      LoadInst* L = IRB.CreateLoad(GEP);
      L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      FunctionModified |= visitVariable(IRB, field_name, field_meta, static_cast<Value*>(L), Vals, Guards, Parents, true);
      
      FunctionModified = true;

    }
    
  }

  return FunctionModified;

}

bool DaikonInstruments::visitVariable(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Value* V, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents, bool isPtr) {

  bool FunctionModified = false;
  
  Type *T = V->getType();
  Value *OneI8 = ConstantInt::get(Int8Ty, 1, true);
  
  if (Vals.find(name) != Vals.end()) {

    if (Vals[name] == nullptr)
      Vals[name] = IRB.CreateAlloca(T);
  
    Instruction *S = IRB.CreateStore(OneI8, Guards[name]);
    S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
    S = IRB.CreateStore(V, Vals[name]);
    S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
    FunctionModified = true;

  }

  if(StructType *ST = dyn_cast<StructType>(T)) {
  
    FunctionModified |= visitStructure(IRB, name, meta, ST, V, Vals, Guards, Parents);
  
  } else if(PointerType* PT = dyn_cast<PointerType>(T)) {

    Type* ET = PT->getElementType();
    StructType* ST = dyn_cast<StructType>(ET);
    if(ST && Parents.find(name) != Parents.end()) {
    
	    bool isParent = Parents.find(name) != Parents.end();
	    
	    if (!isPtr && isParent) {
  
	        FunctionModified |= visitStructure(IRB, name, meta, ST, V, Vals, Guards, Parents);
      
      } else if (isParent) {
      
        size_t SizeIndex = TypeSizeToSizeIndex(LongSize);
	      Value *I = IRB.CreatePtrToInt(V, IntTypeSized[SizeIndex]);
        Value *PageSize = ConstantInt::get(IntTypeSized[SizeIndex], 4096, true);
        
        Instruction* Cmp = IRB.Insert(new ICmpInst(ICmpInst::ICMP_UGT, I, PageSize));
        Instruction* ThenBlock = IRBSplitBlockAndInsertIfThen(IRB, Cmp, Cmp->getNextNode());
        
        IRBuilder<> ThenIRB(ThenBlock);
        
        FunctionModified |= visitStructure(ThenIRB, name, meta, ST, V, Vals, Guards, Parents);
        
        FunctionModified = true;
	      
      }
    
    }

  }

  return FunctionModified;

}

bool DaikonInstruments::iterArguments(IRBuilder<>& IRB, VarMap& Vals, VarMap& Guards, std::set<std::string>& Parents) {

  bool FunctionModified = false;

  for(Function::arg_iterator it = F.arg_begin(); it != F.arg_end(); ++it) {
		Argument *A = &*it;
		Value *V = static_cast<Value*>(A);
		
    std::string name;
    MDNode *meta = nullptr;
    if (V->hasName()) {
      name = V->getName().str();
      for (auto LV : DbgVars) {
        if (LV->getArg() && LV->getName().str() == name)
          meta = LV;
      }
    } else
      name = "arg" + std::to_string(A->getArgNo());
    
    FunctionModified |= visitVariable(IRB, name, meta, V, Vals, Guards, Parents, true);
    
	}
	
	return FunctionModified;

}

bool DaikonInstruments::instrumentFunction() {

  bool FunctionModified = false;

  if (F.isVarArg() || isBlacklisted(&F)) return FunctionModified; // not supported
  
  bool FuncInvs = (Constrs->find(funcname) != Constrs->end());
  if (FuncInvs)
    errs() << "Instrumenting invariants for function " << funcname << "\n";

  std::map<Value*, std::string> declAllocas;
  std::map<Value*, Value*> declCalls;
  Value *ZeroI8 = ConstantInt::get(Int8Ty, 0, true);
  Value *OneI8 = ConstantInt::get(Int8Ty, 1, true);

  for (auto &BB : F) {
    for (auto &Inst : BB) {
      if (DbgDeclareInst* DbgDeclare = dyn_cast<DbgDeclareInst>(&Inst)) {
      
        MDNode* meta = DbgDeclare->getVariable();
        if (DILocalVariable* LV = dyn_cast<DILocalVariable>(meta)) {
          DbgVars.push_back(LV);
        }

        /*Value *A = DbgDeclare->getAddress();
        
        Type* T = A->getType();
        PointerType* PT = dyn_cast<PointerType>(T);
        Type* ET = PT->getElementType();
        
        if(StructType* ST = dyn_cast<StructType>(ET)) {

        } else if (isInterestingType(ET)) {
        
          declCalls[DbgDeclare] = A;
          declAllocas[A] = DbgDeclare->getVariable()->getName();
        
        }*/
        
        /*if (PointerType* PT = dyn_cast<PointerType>(A->getType())) {
        
          Type* ET = PT->getElementType();
          if(StructType* ST = dyn_cast<StructType>(ET)) {
          
            size_t SizeIndex = TypeSizeToSizeIndex(LongSize);
            Instruction* NI = static_cast<Instruction*>(A)->getNextNode();
            IRBuilder NIRB(NI);
            Instruction* S = NIRB.CreateStore(ConstantInt::get(IntTypeSized[SizeIndex], 0, true), A);
            S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          
          }
        
        }*/
        
      } else if (DbgValueInst* DbgValue = dyn_cast<DbgValueInst>(&Inst)) {

        //declCalls[DbgValue->getValue()] = DbgValue->getVariable()->getName();
        
        MDNode* meta = DbgValue->getVariable();
        if (DILocalVariable* LV = dyn_cast<DILocalVariable>(meta)) {
          DbgVars.push_back(LV);
        }

      }
    }
  }

  DITypeRefArray ArgsMeta = static_cast<DISubroutineType*>(F.getSubprogram()->getType())->getTypeArray();

  IRBuilder<> IRB(&*F.getEntryBlock().getFirstInsertionPt());

  Instruction* PrevAflState;

  if (FuncInvs) {
  
    PrevAflState = IRB.CreateLoad(AFLState);
    PrevAflState->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    StoreInst *StoreState = IRB.CreateStore(ConstantInt::get(Int32Ty, 0), AFLState);
    StoreState->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

    auto CST = (*Constrs)[funcname];
    VarMap OrigVals, OrigGuards;
    
    // TODO fast path for vars only in unary constraints (don't use Guards)
    
    for (auto& N : CST["ENTER"]["vars"]) {

      std::string SN = N.get<std::string>();
      OrigVals[SN] = nullptr; // CreateAlloca 
      Instruction *AI = IRB.CreateAlloca(Int8Ty);
      AI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      OrigGuards[SN] = AI;
      StoreInst* S = IRB.CreateStore(ZeroI8, OrigGuards[SN]);
      S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

    }

    std::set<std::string> Parents;
    for (auto& N : CST["ENTER"]["parents"])
      Parents.insert(N.get<std::string>());
    
    FunctionModified |= iterArguments(IRB, OrigVals, OrigGuards, Parents);
    
    for (auto& Pair : OrigVals) {
      if (Pair.second) Pair.second->moveBefore(&*F.getEntryBlock().getFirstInsertionPt());
    }
    
    for (auto& JC : CST["ENTER"]["constrs"]) {
    
      for (auto& NJ : JC["vars"]) {
        
        auto N = NJ.get<std::string>();
        if (OrigVals[N] == nullptr) break;
      
      }
      
      IRBuilder<>* CurIRB = &IRB;
      std::vector<Value*> Loadeds;
      std::vector<Type*> LoadedsTy;
      
      for (auto& NJ : JC["vars"]) {
        
        auto N = NJ.get<std::string>();
        
        LoadInst* GL = CurIRB->CreateLoad(OrigGuards[N]);
        GL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        
        Instruction* Cmp = CurIRB->Insert(new ICmpInst(ICmpInst::ICMP_NE, GL, ZeroI8));
        Instruction* ThenBlock = IRBSplitBlockAndInsertIfThen(*CurIRB, Cmp, Cmp->getNextNode());
        
        IRBuilder<>* ThenIRB = new IRBuilder<>(ThenBlock);
        
        LoadInst* VL = ThenIRB->CreateLoad(OrigVals[N]);
        VL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        
        if (CurIRB != &IRB) delete CurIRB;
        CurIRB = ThenIRB;
        Loadeds.push_back(VL);
        LoadedsTy.push_back(VL->getType());
      
      }
      
      //errs() << "   Call to " << JC["func"].get<std::string>() << " with " << LoadedsTy.size() << " args\n";
      
      FunctionCallee ConstrFn = M.getOrInsertFunction(JC["func"].get<std::string>(), FunctionType::get(VoidTy, LoadedsTy, false));
      CurIRB->CreateCall(ConstrFn, Loadeds);
      if (CurIRB != &IRB) delete CurIRB;
    
    }
    
    size_t exit_num = 0;
    std::vector<Instruction*> returnInsts;

    for (auto &BB : F) {
      for (auto &Inst : BB) {
        if(ReturnInst* RI = dyn_cast<ReturnInst>(&Inst))
          returnInsts.push_back(&Inst);
      }
    }

    for (auto Inst : returnInsts) {
    
      auto& J = CST["EXIT" + std::to_string(exit_num)];
      IRBuilder<> IRB(Inst);
      VarMap Vals, Guards;
      
      StoreInst *StoreState = IRB.CreateStore(PrevAflState, AFLState);
      StoreState->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      for (auto& N : J["vars"]) {

        std::string SN = N.get<std::string>();
        Vals[SN] = nullptr; // CreateAlloca 
        Instruction *AI = IRB.CreateAlloca(Int8Ty);
        AI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        Guards[SN] = AI;
        StoreInst* S = IRB.CreateStore(ZeroI8, Guards[SN]);
        S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

      }

      std::set<std::string> Parents;
      for (auto& N : J["parents"])
        Parents.insert(N.get<std::string>());
      
      FunctionModified |= iterArguments(IRB, Vals, Guards, Parents);
      ReturnInst* RI = static_cast<ReturnInst*>(Inst);
      Value* RV = RI->getReturnValue();
      if (RV) {
        MDNode *RMeta = nullptr;
        if (ArgsMeta.size() > 0) RMeta = ArgsMeta[0];
        FunctionModified |= visitVariable(IRB, "<retval>", RMeta, RV, Vals, Guards, Parents, true);
      }
      
      for (auto& Pair : Vals) {
        if (Pair.second) Pair.second->moveBefore(&*Inst->getParent()->getFirstInsertionPt());
      }
      
      for (auto& JC : J["constrs"]) {
        
        for (auto& NJ : JC["vars"]) {
          
          auto N = NJ.get<std::string>();
          if (N.rfind("ORIG:", 0) == 0)
            if (OrigVals[N] == nullptr) break;
          else
            if (Vals[N] == nullptr) break;
      
        }
        
        IRBuilder<>* CurIRB = &IRB;
        std::vector<Value*> Loadeds;
        std::vector<Type*> LoadedsTy;
        
        for (auto& NJ : JC["vars"]) {
          
          auto N = NJ.get<std::string>();
          bool IsOrig = N.rfind("ORIG:", 0) == 0;
          
          LoadInst* GL;
          if (IsOrig)
            GL = IRB.CreateLoad(OrigGuards[N]);
          else
            GL = IRB.CreateLoad(Guards[N]);
          GL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          
          Instruction* Cmp = CurIRB->Insert(new ICmpInst(ICmpInst::ICMP_NE, GL, ZeroI8));
          Instruction* ThenBlock = IRBSplitBlockAndInsertIfThen(*CurIRB, Cmp, Cmp->getNextNode());
          
          IRBuilder<>* ThenIRB = new IRBuilder<>(ThenBlock);
          
          LoadInst* VL;
          if (IsOrig) VL = ThenIRB->CreateLoad(OrigVals[N]);
          else VL = ThenIRB->CreateLoad(Vals[N]);
          VL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          
          if (CurIRB != &IRB) delete CurIRB;
          CurIRB = ThenIRB;
          Loadeds.push_back(VL);
          LoadedsTy.push_back(VL->getType());
        
        }
        
        FunctionCallee ConstrFn = M.getOrInsertFunction(JC["func"].get<std::string>(), FunctionType::get(VoidTy, LoadedsTy, false));
        CurIRB->CreateCall(ConstrFn, Loadeds);
        if (CurIRB != &IRB) delete CurIRB;

      }
      
      exit_num++;
    
    }
  
  }
  
  /*
  unsigned loop_num = 0;
  // max 2 levels of subloops
  std::vector< std::pair<Loop*, unsigned> > LL;
  
  std::map< Value*, AllocaInst* > initVars;
  
  for (Loop* L : LI) {
    LL.push_back(std::make_pair(L, loop_num++));
    for (Loop* L1 : L->getSubLoops()) {
      LL.push_back(std::make_pair(L1, loop_num++));
      for (Loop* L2 : L->getSubLoops()) {
        LL.push_back(std::make_pair(L2, loop_num++));
      }
    }
  }

  
  std::vector<Value*> loopGuards;  
  for (unsigned i = 0; i < loop_num; ++i) {
    std::string loop_name = funcname + "###loop" + std::to_string(i);
    if (Constrs->find(loop_name) == Constrs->end())
      loopGuards.push_back(nullptr);
    else
      loopGuards.push_back(IRB.CreateAlloca(Int8Ty));
  }
  
  unsigned loop_cnt = 0;
  for (Loop* L : LI) {
    if (loopGuards[loop_cnt]) {
      StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
      S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    }
    ++loop_cnt;
    
    for (BasicBlock *BB : L->getBlocks()) {
      IRBuilder IRB(BB->getFirstNonPHIOrDbg());
      
      for (Loop* L1 : L->getSubLoops()) {
        if (loopGuards[loop_cnt]) {
          StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
          S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        }
        ++loop_cnt;
        
        for (BasicBlock *BB : L1->getBlocks()) {
          IRBuilder IRB(BB->getFirstNonPHIOrDbg());
          
          for (Loop* L2 : L1->getSubLoops()) {

            if (loopGuards[loop_cnt]) {
              StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
              S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            }
            ++loop_cnt;

          }
          
          break;
        }
      }

      break;
    }
  }*/
  /*
  
  for (auto& LP : LL) {
  
    Loop* L = LP.first;
    
    std::string loop_name = funcname + "###loop" + std::to_string(LP.second);
    
    if (Constrs->find(loop_name) == Constrs->end())
      continue;
    
    errs() << "Instrumenting invariants for loop " << loop_name << "\n";

    std::map<Value*, bool> Used;
    for (BasicBlock *BB : L->getBlocks()) {
      for (auto &Inst : *BB) {

        // to avoid Instruction does not dominate all uses!
        if (declAllocas.find(&Inst) != declAllocas.end()) {
          Used[&Inst] = false;
          continue;
        }
        if (declCalls.find(&Inst) != declCalls.end()) {
          Used[declCalls[&Inst]] = false;
          continue;
        }

        for (auto op = Inst.op_begin(); op != Inst.op_end(); ++op) {
          Value* V = op->get();
          if (declAllocas.find(V) != declAllocas.end()) {
            // used in loop
            if (Used.find(V) == Used.end())
              Used[V] = true;
          }
        }

      }
    }
    
    for (auto UP : Used) {
    
      if (UP.second && initVars.find(UP.first) == initVars.end()) {

        initVars[UP.first] = IRB.CreateAlloca(Int8Ty);
      
      }
    
    }

    for (BasicBlock *BB : L->getBlocks()) {

      auto CST = (*Constrs)[loop_name];
      Instruction* First = BB->getFirstNonPHIOrDbg();
      
      auto& J = CST["ENTER"];
      //IRBuilder<> IRBLoopFirst(First);
      IRBuilder<> IRBLoop(First);
      VarMap Vals, Guards;
      
      //LoadInst* LGL = IRBLoopFirst.CreateLoad(loopGuards[LP.second]);
      //LGL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      //Instruction* Cmp = IRBLoopFirst.Insert(new ICmpInst(ICmpInst::ICMP_NE, LGL, ZeroI8));

      //Instruction* ThenBlock, *ElseBlock;
      //IRBSplitBlockAndInsertIfThenElse(IRBLoopFirst, Cmp, Cmp->getNextNode(), &ThenBlock, &ElseBlock);

      //IRBuilder<> IRBLoop(ThenBlock);
      //IRBuilder<> IRBFirst(ElseBlock);
      
      //StoreInst* S = IRBFirst.CreateStore(OneI8, loopGuards[LP.second]);
      //S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

      for (auto& N : J["vars"]) {

        std::string SN = N.get<std::string>();
        Vals[SN] = nullptr; // CreateAlloca 
        Instruction *AI = IRB.CreateAlloca(Int8Ty); // do not allocate in loop
        AI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        Guards[SN] = AI;
        StoreInst* S = IRBLoop.CreateStore(ZeroI8, Guards[SN]);
        S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

      }

      std::set<std::string> Parents;
      for (auto& N : J["parents"])
        Parents.insert(N.get<std::string>());

      std::set<std::string> Visited;
      for (auto UP : Used) {

        if (!UP.second) continue;
        Value *V = UP.first;

        if (Visited.find(declAllocas[V]) != Visited.end()) continue;
        Visited.insert(declAllocas[V]);

        if (AllocaInst* AI = dyn_cast<AllocaInst>(V)) {

          //errs() << *V << "       " << *V->getType() << "\n";
          Type* T = V->getType();
          PointerType* PT = dyn_cast<PointerType>(T);
          Type* ET = PT->getElementType();
          
          LoadInst* IVL = IRBLoop.CreateLoad(initVars[V]);
          IVL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          
          Instruction* Cmp = IRBLoop.Insert(new ICmpInst(ICmpInst::ICMP_NE, IVL, ZeroI8));
          Instruction* ThenBlock = IRBSplitBlockAndInsertIfThen(IRBLoop, Cmp, Cmp->getNextNode());
          
          IRBuilder<> IRBInited(ThenBlock);
          
          if(StructType* ST = dyn_cast<StructType>(ET)) {

            // TODO
            // visitVariable(IRBLoop, declAllocas[V], V, Vals, Guards, Parents, true);

          } else if (isInterestingType(ET)) {

            LoadInst* L = IRBInited.CreateLoad(AI);
            L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            visitVariable(IRBInited, declAllocas[V], L, Vals, Guards, Parents, true);

          }
        
        }
      }

      for (auto& Pair : Vals) {
        if (Pair.second) Pair.second->moveBefore(&*F.getEntryBlock().getFirstInsertionPt());
      }

      for (auto& JC : J["constrs"]) {
        switch (JC["type"].get<int>()) {
          case 1: {

            auto N = JC["v0"].get<std::string>();
            if (Vals[N] == nullptr) break;

            LoadInst* GL = IRBLoop.CreateLoad(Guards[N]);
            GL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

            Instruction* Cmp = IRBLoop.Insert(new ICmpInst(ICmpInst::ICMP_NE, GL, ZeroI8));
            Instruction* ThenBlock = IRBSplitBlockAndInsertIfThen(IRBLoop, Cmp, Cmp->getNextNode());

            IRBuilder<> ThenIRB(ThenBlock);

            LoadInst* VL = ThenIRB.CreateLoad(Vals[N]);
            VL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

            FunctionCallee ConstrFn = M.getOrInsertFunction(JC["func"].get<std::string>(), VoidTy, VL->getType());
            ThenIRB.CreateCall(ConstrFn, ArrayRef<Value*>{VL});

            break;
          }
          case 2: {

            auto N1 = JC["v0"].get<std::string>();
            auto N2 = JC["v1"].get<std::string>();

            if (Vals[N1] == nullptr || Vals[N2] == nullptr) break;
            
            LoadInst* GL = IRBLoop.CreateLoad(Guards[N1]);
            GL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            
            Instruction* Cmp1 = IRBLoop.Insert(new ICmpInst(ICmpInst::ICMP_NE, GL, ZeroI8));
            Instruction* ThenBlock1 = IRBSplitBlockAndInsertIfThen(IRBLoop, Cmp1, Cmp1->getNextNode());
            
            IRBuilder<> ThenIRB1(ThenBlock1);

            GL = ThenIRB1.CreateLoad(Guards[N2]);
            GL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            
            Instruction* Cmp2 = ThenIRB1.Insert(new ICmpInst(ICmpInst::ICMP_NE, GL, ZeroI8));
            Instruction* ThenBlock2 = IRBSplitBlockAndInsertIfThen(ThenIRB1, Cmp2, Cmp2->getNextNode());
            
            IRBuilder<> ThenIRB2(ThenBlock2);
            
            LoadInst* VL1 = ThenIRB2.CreateLoad(Vals[N1]);
            VL1->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            LoadInst* VL2 = ThenIRB2.CreateLoad(Vals[N2]);
            VL2->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            
            FunctionCallee ConstrFn = M.getOrInsertFunction(JC["func"].get<std::string>(), VoidTy, VL1->getType(), VL2->getType());
            ThenIRB2.CreateCall(ConstrFn, ArrayRef<Value*>{VL1, VL2});

            break;
          }
          default:
            break;
        }
      }

      break;
    }
    
    loop_num++;

  }
  
  for (auto& Pair : initVars) {
    if (Pair.second) {
      Pair.second->moveBefore(&*F.getEntryBlock().getFirstInsertionPt());
      IRBuilder IRBInit(Pair.second->getNextNode());
      StoreInst* S = IRBInit.CreateStore(ZeroI8, Pair.second);
      S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    }
  }
  
  for (auto &BB : F) {
    for (auto &Inst : BB) {
      if (StoreInst* ST = dyn_cast<StoreInst>(&Inst)) {
        Value* PT = ST->getPointerOperand();
        if (initVars.find(PT) == initVars.end()) continue;
        
        IRBuilder IRBInit(ST->getNextNode());
        StoreInst* S = IRBInit.CreateStore(OneI8, initVars[PT]);
        S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      }
    }
  }

  /*for (auto &BB : F)
  for (auto &I : BB)
  if (I.getParent() != &BB) {
  
    errs() << "ERROR " << I << "\n";
    errs() << "PARENT " << *I.getParent() << "\n";
    errs() << "BB " << BB << "\n";
  
  }*/
  
  return FunctionModified;
	
}

bool DaikonInstruments::isInterestingType(Type *T) {

	switch (T->getTypeID()) {
		case Type::IntegerTyID:
		case Type::FloatTyID:
		case Type::DoubleTyID:
		// case Type::ArrayTyID:
		// case Type::VectorTyID: 
			return true;

		default:
			break;
	}
	
	if(StructType *ST = dyn_cast<StructType>(T)) {
  
    return true;
  
  } else if(PointerType* PT = dyn_cast<PointerType>(T)) {

    Type* ET = PT->getElementType();
    if(StructType* ST = dyn_cast<StructType>(ET))
      return true;

  }
	
	return false;

}

class DaikonFunctionPass : public FunctionPass {
public:
  static char ID;

  explicit DaikonFunctionPass() : FunctionPass(ID) {}

  void getAnalysisUsage(AnalysisUsage &AU) const override {
    AU.setPreservesCFG();
    AU.addRequired<LoopInfoWrapperPass>();
  }

  StringRef getPassName() const override {
    return "DaikonFunctionPass";
  }

  bool runOnFunction(Function &F) override {
    Module &M = *F.getParent();
    LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
    DaikonInstruments DI(M, F, LI);
    bool r = DI.instrumentFunction();
    verifyFunction(F);
    return r;
  }
};


char DaikonFunctionPass::ID = 0;

static void registerDaikonPass(const PassManagerBuilder &,
                               legacy::PassManagerBase &PM) {

  PM.add(new DaikonFunctionPass());

}

static RegisterStandardPasses RegisterDaikonPass(
    PassManagerBuilder::EP_OptimizerLast, registerDaikonPass);

static RegisterStandardPasses RegisterDaikonPass0(
    PassManagerBuilder::EP_EnabledOnOptLevel0, registerDaikonPass);

static RegisterPass<DaikonFunctionPass>
    X("daikon-func", "DaikonFunctionPass",
      false,
      false
    );

