import sys
import os
import re
import ast
import json
import argparse

abort_mode = False

INT_RE = re.compile(r"^[-+]?[0-9]+$")
FLOAT_RE = re.compile("^[-+]?[0-9]*\.?[0-9]+([eE][-+]?[0-9]+)?$")

BIN_OPS = ("==", "!=", ">", "<", ">=", "<=")
GT_CMP_OPS = (">", ">=")
LT_CMP_OPS = ("<", "<=")

OPERATORS = ("+", "-", "*", "/", "%", "&", "|", "^", "~", "==", "!=", ">", "<", ">=", "<=")

CMP_MAX_OPS = ("!=", "<", ">", ">=", "<=")

code = []
fnid = 0
max_id = 0
set_id = 0

specs = {}

blacklist = {}
var_types = {}

def next_power_of_2(x):  
    return 1 if x == 0 else 2**(x - 1).bit_length()

def is_int(x):
    return re.match(INT_RE, x) or (x[-1] == "L" and re.match(INT_RE, x[:-1]))

def is_float(x):
    return re.match(FLOAT_RE, x)

def is_ident(x):
    if len(x) == 0: return False
    if x[0] in "1234567890": return False
    for c in x:
        if c not in "qwertyuiopasdfghjklzxcvbnmQWERTYUIOPASDFGHJKLZXCVBNM1234567890_.:<>":
            return False
    return True

def get_c_type(t):
    base_types = {"i8": "uint8_t", "i16": "uint16_t", "i32": "uint32_t",
                  "i64": "uint64_t", "float": "float", "double": "double"}
    if t in base_types:
        return base_types[t]
    return "uintptr_t"


def is_in_blacklist(v, bl):
    n = v
    if n.startswith("orig("):
        n = v[len("orig("):v.find(")")]
        if n in bl: return True
    if n.startswith("ORIG:"):
        n = v[len("ORIG:"):]
        if n in bl: return True
    return n in bl

def parse_inv(funcname, ppt, inv):
    global code, fnid, max_id, set_id, blacklist, var_types
    if len(inv) < 2:
        return
    bl = []
    if funcname in blacklist and ppt in blacklist[funcname]:
        bl = blacklist[funcname][ppt]
    if ppt == "EXIT" and ppt not in var_types[funcname]:
        types = var_types[funcname]["EXIT0"]
    else:
        types = var_types[funcname][ppt]
    
    if len(inv) >= 5 and inv[1] == "one" and inv[2] == "of" and inv[3] == "{" and inv[-1] == "}":
        x = inv[0]
        if x.startswith("orig("):
            x = x[len("orig("):x.find(")")]
            x = "ORIG:" + x
        if not is_ident(x):
            return
        t = get_c_type(types[x.replace("ORIG:", "")])
        nums = "".join(inv[4: -1]).split(",")
        cnt = 0
        checks = []
        for n in nums:
            n = n.strip()
            if re.match(FLOAT_RE, n) is None and not is_int(n):
                return
            if n.endswith("L"):
                n = n[:-1]
                if int(n.strip()) > 2**32-1:
                    n += "LL"
            n = "(%s)" % t + n
            checks.append("v0 == " + n)
        return " || ".join(checks), [(t, x)]
    
    numvars = 0
    variables = []
    parsed = []
    for x in inv:
        pow2 = False
        if x.endswith("**2"):
            pow2 = True
            x = x[:-3]
        if x == "null":
            x = "0"
        if x.startswith("orig("):
            x = x[len("orig("):x.find(")")]
            x = "ORIG:" + x
        if is_int(x):
            if "L" in x:
                x = x[:-1]
            if int(x.strip()) >= 2**32:
                x += "LL"
            parsed += [x]
        elif is_float(x):
            parsed += [x]
        elif x in OPERATORS:
            parsed += [x]
        elif is_ident(x):
            if is_in_blacklist(x, bl):
                return
            if pow2:
                parsed += ["v%d * v%d" % (numvars, numvars)]
            else:
                parsed += ["v%d" % numvars]
            numvars += 1
            if x.replace("ORIG:", "") not in types:
                return
            t = get_c_type(types[x.replace("ORIG:", "")])
            #if t == "uintptr_t": # TODO should we hadle pointer constraints?
            #    return
            variables += [(t, x)]
        else:
            return
    notzero = []
    for i in range(len(parsed)):
        if parsed[i] in ("/", "%"):
            if is_ident(parsed[i+1]):
                notzero.append(parsed[i+1])
    #print(" ".join(parsed), variables)
    return " && ".join(notzero + [" ".join(parsed)]), variables

def add_to_spec(funcname, ppt, invd):
    global specs
    specs[funcname] = specs.get(funcname, {})
    specs[funcname][ppt] = specs[funcname].get(ppt, {})
    specs[funcname][ppt]["vars"] = specs[funcname][ppt].get("vars", [])
    specs[funcname][ppt]["parents"] = specs[funcname][ppt].get("parents", [])
    specs[funcname][ppt]["constrs"] = specs[funcname][ppt].get("constrs", [])
    for v in invd["vars"]:
        if v not in specs[funcname][ppt]["vars"]:
            p = ""
            for s in v.split(".")[:-1]:
                p += s
                if p not in specs[funcname][ppt]["parents"]:
                    specs[funcname][ppt]["parents"].append(p)
                p += "."
            specs[funcname][ppt]["vars"].append(v)
    specs[funcname][ppt]["constrs"].append(invd)

def process_invariant(funcname, ppt, inv):
    global code, fnid, max_id, set_id, blacklist
    if ppt != "ENTER": return
    parsed = parse_inv(funcname, ppt, inv)
    if parsed is None:
        return
    constr, variables = parsed
    bl = []
    if funcname in blacklist and ppt in blacklist[funcname]:
        bl = blacklist[funcname][ppt]
    for v in variables:
        p = ""
        for s in v[1].split(".")[:-1]:
            p += s
            if p.replace("ORIG:", "") in bl:
                return
            p += "."
    params = []
    fmtvals = []
    i = 0
    for v in variables:
        params.append("%s v%s" % (v[0], i))
        fmtvals.append("(long long)(v%d)" % i)
        i += 1
    params = ", ".join(params)
    fmt = "\"(" + ("%lld, " * len(fmtvals))[:-2] + ")\""
    fmtvals = ", ".join(fmtvals)
    add_to_spec(funcname, ppt, {"type": len(variables), "vars": list(map(lambda x: x[1], variables)), "func": "__daikon_constr_%d" % fnid})
    code += [
"""
void __daikon_constr_%d(%s) {
  HANDLE_CONSTR(%d, %s, \"%s\", %s, %s);
}
""" % (fnid, params, fnid, constr, funcname + "[" + ppt + "]: " + " ".join(inv), fmt, fmtvals)]
    fnid += 1

def process_daikon_out(daikon):
    daikon = daikon.replace("Exiting Daikon.\n", "")
    daikon = daikon.split("===========================================================================\n")[1:]
    for invs in daikon:
        invs = invs.split("\n")
        funcname = invs[0].split("():::")[0]
        ppt = invs[0].split("():::")[1]
        invs = invs[1:]
        for inv in invs:
            i = inv.split()
            if len(i) == 0: continue
            process_invariant(funcname, ppt, i)

DESCR = "Reconstruct decls file"
opt = argparse.ArgumentParser(description=DESCR, formatter_class=argparse.RawTextHelpFormatter)
opt.add_argument("-i", action='store', required=True)
opt.add_argument("-b", action='store')
opt.add_argument("-l", action='store', required=True)
args = opt.parse_args()

if args.b:
    with open(args.b) as f:
        blacklist = json.load(f)

with open(args.l) as f:
    body = f.read()
    body = ast.literal_eval(body)
    for data in body:
        var_types[data["name"]] = {}
        for ppt in data["ppts"]:
            var_types[data["name"]][ppt] = {}
            for v in data["ppts"][ppt]:
                var_types[data["name"]][ppt][v["name"]] = v["type"]

with open(args.i) as f:
    process_daikon_out(f.read())

with open("constraints.c", "w") as f:
    f.write("#include \"stdint.h\"\n")
    f.write("#include \"stdio.h\"\n")
    f.write("#include \"stdlib.h\"\n")
    f.write("#include \"assert.h\"\n")
    if abort_mode:
        f.write("""

#define HANDLE_CONSTR(id, inv, msg, fmt, ...) do { \\
 \\
  if (!(inv)) { \\
    fprintf(stderr, "VIOLATED INVARIANT: %s -- " fmt "\\n", msg, __VA_ARGS__); \\
    if (!getenv("INVS_NO_ABORT")) abort(); \\
  } \\
 \\
} while(0)

""")
    else:
        f.write("""
#define INVARIANTS_MAP_SIZE 32768

extern uint8_t *__afl_area_ptr;
extern uint32_t *__afl_invariants_count;
extern uint8_t *__afl_invariants_map;
extern uint8_t *__afl_max_map;

// extern __thread uint32_t __afl_state;
extern __thread uint32_t __afl_prev_loc;

#define HANDLE_CONSTR(id, inv, msg, fmt, ...) do { \\
 \\
  if (__afl_invariants_map) { \\
    if (!(inv)) { \\
   \\
      uint32_t k = (id) & (INVARIANTS_MAP_SIZE -1); \\
   \\
      if (__afl_invariants_map[k] == 0) { \\
        __afl_invariants_map[k] = 1; \\
        *__afl_invariants_count += 1; \\
      } \\
      if (__afl_invariants_map[k] != 0xff) __afl_prev_loc ^= k; \\
   \\
    } \\
  } else { \\
    if (!(inv)) \\
      fprintf(stderr, "VIOLATED INVARIANT #%d: %s -- " fmt "\\n", id, msg, __VA_ARGS__); \\
  } \\
 \\
} while(0)

""")
    f.write("".join(code) + "\n")

with open("daikon_constrs.json", "w") as f:
    json.dump(specs, f, indent=2)

