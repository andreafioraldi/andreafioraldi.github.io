#include <stdio.h>
#include <stdlib.h>

// clang-10 -g -fno-discard-value-names -c -emit-llvm test.c 
// opt-10 -load=./pass.so -daikon-func ./test.bc 

typedef int pippo;

enum foo {N1, N2, N3};

struct C {
	struct B *b;
	float z;
};

struct B {
	pippo                      x;                    /*     0     4 */
	struct C* c;
};
struct A {
	struct B                   b;                    /*     0     4 */
	int                   y;                    /*     4     4 */
	int k;
};

struct C* cc() {
  struct C* c = malloc(sizeof(struct C));
  c->z = -(0.0 / 0.0);
  return c;
}

struct A* aa() {
  struct A* c = malloc(sizeof(struct A));
  return c;
}

int pii(struct A* s, int h) {

  int u = 0;
  
  s->b.x = 0;

  s->k = s->y;
  while (s->k == u) {
      int y = u+1;
      printf("2");
      u = y;
      s->k--;
  }

  return h +u;

}

float foo(struct C *c) {

  if (!c->b) {
    c->b = malloc(sizeof(struct B));
    return 0;
  }
  c->b->c = malloc(sizeof(struct C));
  return c->b->c->z;

}

int main() {

  struct C c = {0};
  foo(&c);
  foo(&c);
  foo(&c);
  foo(&c);

}

