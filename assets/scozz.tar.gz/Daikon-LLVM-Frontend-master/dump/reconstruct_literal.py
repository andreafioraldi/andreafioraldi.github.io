import argparse
import ast
import sys
import os

DESCR = "Reconstruct literal file"
opt = argparse.ArgumentParser(description=DESCR, formatter_class=argparse.RawTextHelpFormatter)
opt.add_argument("-i", action='store', required=True)
args = opt.parse_args()

body = "[\n"
for fname in os.listdir(args.i):
    if not fname.endswith(".literal.part"):
        continue
    path = os.path.join(args.i, fname)
    with open(path) as f:
        body += f.read()
body += "\n]"

print(body)
