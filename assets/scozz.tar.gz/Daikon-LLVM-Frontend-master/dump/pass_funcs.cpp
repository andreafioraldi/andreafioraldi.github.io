#include "llvm/IR/Function.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/PassManager.h"
#include "llvm/ADT/ArrayRef.h"
#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/DepthFirstIterator.h"
#include "llvm/ADT/SmallPtrSet.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/ADT/Statistic.h"
#include "llvm/ADT/StringExtras.h"
#include "llvm/ADT/StringRef.h"
#include "llvm/ADT/Triple.h"
#include "llvm/ADT/Twine.h"
#include "llvm/Analysis/MemoryBuiltins.h"
#include "llvm/Analysis/TargetLibraryInfo.h"
#include "llvm/Analysis/ValueTracking.h"
#include "llvm/Analysis/LoopInfo.h"
#include "llvm/BinaryFormat/MachO.h"
#include "llvm/IR/Argument.h"
#include "llvm/IR/Attributes.h"
#include "llvm/IR/BasicBlock.h"
#include "llvm/IR/CallSite.h"
#include "llvm/IR/Comdat.h"
#include "llvm/IR/Constant.h"
#include "llvm/IR/Constants.h"
#include "llvm/IR/DIBuilder.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/DebugInfoMetadata.h"
#include "llvm/IR/DebugLoc.h"
#include "llvm/IR/DerivedTypes.h"
#include "llvm/IR/Dominators.h"
#include "llvm/IR/Function.h"
#include "llvm/IR/GlobalAlias.h"
#include "llvm/IR/GlobalValue.h"
#include "llvm/IR/GlobalVariable.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/IR/InlineAsm.h"
#include "llvm/IR/InstVisitor.h"
#include "llvm/IR/InstrTypes.h"
#include "llvm/IR/Instruction.h"
#include "llvm/IR/Instructions.h"
#include "llvm/IR/IntrinsicInst.h"
#include "llvm/IR/Intrinsics.h"
#include "llvm/IR/LLVMContext.h"
#include "llvm/IR/MDBuilder.h"
#include "llvm/IR/Metadata.h"
#include "llvm/IR/Module.h"
#include "llvm/IR/Type.h"
#include "llvm/IR/Use.h"
#include "llvm/IR/Value.h"
#include "llvm/IR/Verifier.h"
#include "llvm/IR/DebugInfo.h"
#include "llvm/IR/LegacyPassManager.h"
#include "llvm/MC/MCSectionMachO.h"
#include "llvm/Pass.h"
#include "llvm/Support/Casting.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/Debug.h"
#include "llvm/Support/ErrorHandling.h"
#include "llvm/Support/MathExtras.h"
#include "llvm/Support/ScopedPrinter.h"
#include "llvm/Support/raw_ostream.h"
#include "llvm/Transforms/Instrumentation.h"
#include "llvm/Transforms/Utils/ASanStackFrameLayout.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"
#include "llvm/Transforms/Utils/Local.h"
#include "llvm/Transforms/Utils/ModuleUtils.h"
#include "llvm/Transforms/Utils/PromoteMemToReg.h"
#include "llvm/Transforms/IPO/PassManagerBuilder.h"
#include <algorithm>
#include <cassert>
#include <cstddef>
#include <cstdint>
#include <iomanip>
#include <limits>
#include <memory>
#include <sstream>
#include <string>
#include <vector>
#include <map>
#include <tuple>
#include <fstream>

#define MAX_DEPTH 3

using namespace llvm;

static size_t TypeSizeToSizeIndex(uint32_t TypeSize) {
  size_t Res = countTrailingZeros(TypeSize / 8);
  return Res;
}

void ReplaceAll(std::string& S, std::string P, std::string R) {
	size_t pos = S.find(P);
	while(pos != std::string::npos) {
		S.replace(pos, P.size(), R);
		pos = S.find(P, pos + R.size());
	}
}

DIType* GetFieldMeta(MDNode* meta, unsigned Idx) {

  DIType* Ty;
  if (DIVariable* D = dyn_cast<DIVariable>(meta)) {
    Ty = D->getType();
  } else if (DIType* T = dyn_cast<DIType>(meta)) {
    Ty = T;
  } else return nullptr;
  
  DIType* TmpTy = Ty;
  
  // recurse typedefs
  for (unsigned i = 0; i < 128 && TmpTy->getTag() == dwarf::DW_TAG_typedef; ++i) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }

  if (TmpTy->getTag() == dwarf::DW_TAG_pointer_type) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }
  
  // recurse typedefs
  for (unsigned i = 0; i < 128 && TmpTy->getTag() == dwarf::DW_TAG_typedef; ++i) {
    DIDerivedType* DTy = (DIDerivedType*)TmpTy;
    TmpTy = DTy->getBaseType();
    if (!TmpTy) return nullptr;
  }
  
  if (TmpTy->getTag() != dwarf::DW_TAG_structure_type)
    return nullptr;

  DINodeArray Fields = static_cast<DICompositeType*>(TmpTy)->getElements();
  if (Idx < Fields.size())
    return static_cast<DIType*>(Fields[Idx]);

  return nullptr;

}

void IRBSplitBlockAndInsertIfThenElse(IRBuilder<>& IRB, Value *Cond,
                                      Instruction *SplitBefore,
                                      Instruction **ThenTerm,
                                      Instruction **ElseTerm) {
  BasicBlock *Head = SplitBefore->getParent();
  BasicBlock *Tail = Head->splitBasicBlock(SplitBefore->getIterator());
  Instruction *HeadOldTerm = Head->getTerminator();
  LLVMContext &C = Head->getContext();
  BasicBlock *ThenBlock = BasicBlock::Create(C, "", Head->getParent(), Tail);
  BasicBlock *ElseBlock = BasicBlock::Create(C, "", Head->getParent(), Tail);
  *ThenTerm = BranchInst::Create(Tail, ThenBlock);
  (*ThenTerm)->setDebugLoc(SplitBefore->getDebugLoc());
  *ElseTerm = BranchInst::Create(Tail, ElseBlock);
  (*ElseTerm)->setDebugLoc(SplitBefore->getDebugLoc());
  BranchInst *HeadNewTerm =
   BranchInst::Create(/*ifTrue*/ThenBlock, /*ifFalse*/ElseBlock, Cond);
  ReplaceInstWithInst(HeadOldTerm, HeadNewTerm);
  IRB.SetInsertPoint(&*Tail->getFirstInsertionPt());
}


struct DaikonInstruments {

  DaikonInstruments(Module& _M, Function &_F, LoopInfo &_LI) : M(_M), F(_F), LI(_LI) {
    initialize();
  }
  
  static bool isBlacklisted(const Function *F) {

    static const char *Blacklist[] = {

        "asan.", "llvm.", "sancov.", "__ubsan_handle_", "ign.", "__afl_",
        "_fini", "__libc_csu", "__asan",  "__msan", "msan.", "LLVMFuzzer"

    };

    for (auto const &BlacklistFunc : Blacklist) {

      if (F->getName().startswith(BlacklistFunc)) return true;

    }
    
    //if (F->getName() == "main") return true;
    if (F->getName() == "_start") return true;

    return false;

  }
  
  void initialize();
  bool instrumentFunction();
  
  bool dumpStructureNosense(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, int depth = 0);
  bool dumpVariableNosense(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Type *T, int depth = 0);

  bool dumpStructure(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, Value* V, int depth = 0);
  bool dumpVariable(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Value* V, bool isParam, std::string parent = "", bool isPtr = true, int depth = 0);

  bool iterArguments(IRBuilder<>& IRB);
  
  bool isInterestingType(Type *T);
  
  Type *VoidTy, *Int8Ty, *Int16Ty, *Int32Ty, *Int64Ty, *FloatTy, *DoubleTy,
       *StructTy, *Int8PTy, *Int16PTy, *Int32PTy, *Int64PTy, *FloatPTy,
       *DoublePTy, *StructPTy, *FuncTy;
  Type *IntTypeSized[4];

  Function* dbgDeclareFn;

  FunctionCallee daikonDumpSignedIntFns[4];
  FunctionCallee daikonDumpFloatFn, daikonDumpDoubleFn;
  FunctionCallee daikonDumpNosenseFn;
  
  FunctionCallee daikonDumpLockFn, daikonDumpUnlockFn;
  FunctionCallee daikonDumpEnterPrologueFn, daikonDumpExitPrologueFn,
                 daikonDumpEpilogueFn, daikonDumpLoopPrologueFn;
  
  FunctionCallee daikonAreaIsMappedFn, daikonAreaIsValidFn;
  
  LLVMContext *C;
  Module& M;
  Function &F;
  LoopInfo &LI;
  int LongSize;
  
  bool hasCalls;
  std::map< Type*, std::set<unsigned> > usedFields;
  std::map< Type*, MDNode* > structMDs;
  std::map< Type*, bool > usedForCalls;
  
  std::vector<DILocalVariable*> DbgVars;
  
  std::string funcname;
  std::ofstream decls;
  std::string daikon_output_path;

};

void DaikonInstruments::initialize() {

  if (getenv("DAIKON_OUTPUT_PATH"))
    daikon_output_path = getenv("DAIKON_OUTPUT_PATH");
  else
    daikon_output_path = "daikon_output";
  
  funcname = M.getModuleIdentifier() + ":" + F.getName().str();
  if (funcname.size() >= 2 && funcname[0] == '.' && funcname[1] == '/')
    funcname.erase(0, 2);
  ReplaceAll(funcname, "\\", "\\\\"); // daikon naming convention
  ReplaceAll(funcname, " ", "\\_");
  ReplaceAll(funcname, "/", "_");

  C = &(M.getContext());
  
  LongSize = M.getDataLayout().getPointerSizeInBits();

  VoidTy = Type::getVoidTy(*C);

	Int8Ty = IntegerType::get(*C, 8);
	Int16Ty = IntegerType::get(*C, 16);
	Int32Ty = IntegerType::get(*C, 32);
	Int64Ty = IntegerType::get(*C, 64);

	FloatTy = Type::getFloatTy(*C);
	DoubleTy = Type::getDoubleTy(*C);

	StructTy = StructType::create(*C);
	
	Int8PTy  = PointerType::get(Int8Ty, 0);
	Int16PTy = PointerType::get(Int16Ty, 0);
	Int32PTy = PointerType::get(Int32Ty, 0);
	Int64PTy = PointerType::get(Int64Ty, 0);

	FloatPTy = PointerType::get(FloatTy, 0);
	DoublePTy = PointerType::get(DoubleTy, 0);

	StructPTy = PointerType::get(StructTy, 0);

	FuncTy = FunctionType::get(VoidTy, true);

	dbgDeclareFn = M.getFunction("llvm.dbg.declare");
	
	IntTypeSized[0] = Int8Ty;
	IntTypeSized[1] = Int16Ty;
	IntTypeSized[2] = Int32Ty;
	IntTypeSized[3] = Int64Ty;
	
	daikonDumpSignedIntFns[0] = M.getOrInsertFunction("__daikon_dump_i8", VoidTy, Int8PTy, Int8Ty);
	daikonDumpSignedIntFns[1] = M.getOrInsertFunction("__daikon_dump_i16", VoidTy, Int8PTy, Int16Ty);
	daikonDumpSignedIntFns[2] = M.getOrInsertFunction("__daikon_dump_i32", VoidTy, Int8PTy, Int32Ty);
	daikonDumpSignedIntFns[3] = M.getOrInsertFunction("__daikon_dump_i64", VoidTy, Int8PTy, Int64Ty);
	
	daikonDumpFloatFn = M.getOrInsertFunction("__daikon_dump_f", VoidTy, Int8PTy, FloatTy);
	daikonDumpDoubleFn = M.getOrInsertFunction("__daikon_dump_d", VoidTy, Int8PTy, DoublePTy);
	
	daikonDumpNosenseFn = M.getOrInsertFunction("__daikon_dump_nosense", VoidTy, Int8PTy);
	
	daikonDumpLockFn = M.getOrInsertFunction("__daikon_dump_lock", VoidTy);
	daikonDumpUnlockFn = M.getOrInsertFunction("__daikon_dump_unlock", VoidTy);
	
	Type* SizeTTy = IntTypeSized[TypeSizeToSizeIndex(LongSize)];
	daikonDumpEnterPrologueFn = M.getOrInsertFunction("__daikon_dump_enter_prologue", SizeTTy, Int8PTy);
	daikonDumpExitPrologueFn = M.getOrInsertFunction("__daikon_dump_exit_prologue", VoidTy, Int8PTy, Int32Ty, SizeTTy);
	daikonDumpEpilogueFn = M.getOrInsertFunction("__daikon_dump_epilogue", VoidTy);
	daikonDumpLoopPrologueFn = M.getOrInsertFunction("__daikon_dump_loop_prologue", SizeTTy, Int8PTy, Int32Ty);
	
	daikonAreaIsMappedFn = M.getOrInsertFunction("__daikon_area_is_mapped", Int8Ty, Int8PTy, SizeTTy);
	daikonAreaIsValidFn = M.getOrInsertFunction("__daikon_area_is_valid", Int8Ty, Int8PTy, SizeTTy);

}

bool DaikonInstruments::dumpStructureNosense(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, int depth) {

  bool FunctionModified = false;
  unsigned Num = ST->getNumElements();
  
  for(unsigned Idx = 0; Idx < Num; ++Idx) {
  
    if (!usedForCalls[ST] && usedFields[ST].find(Idx) == usedFields[ST].end())
      continue;

    Type* T = ST->getElementType(Idx);
    
    if (!isInterestingType(T)) continue;
    
    std::string field_name = name + ".field" + std::to_string(Idx);
    DIType* field_meta = nullptr;
    if (meta) {
      field_meta = GetFieldMeta(meta, Idx);
      if (field_meta) {
        field_name = name + "." + field_meta->getName().str();
        field_meta = static_cast<DIDerivedType*>(field_meta)->getBaseType();
      }
    }

    if(StructType *FST = dyn_cast<StructType>(T)) {
    
      Value *N = IRB.CreateGlobalStringPtr(field_name);
      CallInst* CI = IRB.CreateCall(daikonDumpNosenseFn, ArrayRef<Value*>{N});
      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
      FunctionModified |= dumpVariableNosense(IRB, field_name, field_meta, T, depth);
    
    } else {

      FunctionModified |= dumpVariableNosense(IRB, field_name, field_meta, T, depth+1);
      
    }
    
  }

  return FunctionModified;

}

bool DaikonInstruments::dumpVariableNosense(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Type *T, int depth) {

  bool FunctionModified = false;
  
  if(StructType *ST = dyn_cast<StructType>(T)) {
  
    if (depth < MAX_DEPTH)
      FunctionModified |= dumpStructureNosense(IRB, name, meta, ST, depth);
  
  } else if(PointerType* PT = dyn_cast<PointerType>(T)) {
  
    Type* ET = PT->getElementType();
    if(StructType* ST = dyn_cast<StructType>(ET)) {
    
      Value *N = IRB.CreateGlobalStringPtr(name);
      CallInst* CI = IRB.CreateCall(daikonDumpNosenseFn, ArrayRef<Value*>{N});
      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
      if (depth < MAX_DEPTH)
        FunctionModified |= dumpStructureNosense(IRB, name, meta, ST, depth);
    }
  
  } else {
  
    Value *N = IRB.CreateGlobalStringPtr(name);
    CallInst* CI = IRB.CreateCall(daikonDumpNosenseFn, ArrayRef<Value*>{N});
    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

    FunctionModified = true;
  
  }
  
  return FunctionModified;

}

bool DaikonInstruments::dumpStructure(IRBuilder<>& IRB, const std::string& name, MDNode* meta, StructType *ST, Value* V, int depth) {

  bool FunctionModified = false;
  unsigned Num = ST->getNumElements();
  
  for(unsigned Idx = 0; Idx < Num; ++Idx) {
  
    if (!usedForCalls[ST] && usedFields[ST].find(Idx) == usedFields[ST].end())
      continue;

    Type* T = ST->getElementType(Idx);
    
    if (!isInterestingType(T)) continue;
    
    std::string field_name = name + ".field" + std::to_string(Idx);
    DIType* field_meta = nullptr;
    if (meta) {
      field_meta = GetFieldMeta(meta, Idx);
      if (field_meta) {
        field_name = name + "." + field_meta->getName().str();
        field_meta = static_cast<DIDerivedType*>(field_meta)->getBaseType();
      }
    }
    
    Value* indexList[2] = {ConstantInt::get(Int32Ty, 0), ConstantInt::get(Int32Ty, Idx)};
    Value* GEP = IRB.CreateInBoundsGEP(V, ArrayRef<Value*>(indexList, 2));

    if(StructType *FST = dyn_cast<StructType>(T)) {
    
      FunctionModified |= dumpVariable(IRB, field_name, field_meta, GEP, false, name, false, depth);
    
    } else {
    
      bool IsPtr = true;
    
      switch (T->getTypeID()) {
		    case Type::IntegerTyID:
		      if ( T->getPrimitiveSizeInBits() > 64) break;
		    case Type::FloatTyID:
		    case Type::DoubleTyID: {
		    
		      IsPtr = false;
		    
		      Value *ZeroI8 = ConstantInt::get(Int8Ty, 0, true);
		      size_t SizeIndex = TypeSizeToSizeIndex(LongSize);
		      Value *Ptr = IRB.CreateBitCast(GEP, Int8PTy);
          Value *SizeVal = ConstantInt::get(IntTypeSized[SizeIndex], T->getPrimitiveSizeInBits() / 8, true);
		      
		      Instruction* IsValid = IRB.CreateCall(daikonAreaIsValidFn, ArrayRef<Value*>{Ptr, SizeVal});
          IsValid->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          Instruction* Cmp = IRB.Insert(new ICmpInst(ICmpInst::ICMP_NE, IsValid, ZeroI8));

          Instruction* ThenBlock, *ElseBlock;
          IRBSplitBlockAndInsertIfThenElse(IRB, Cmp, Cmp->getNextNode(), &ThenBlock, &ElseBlock);

          IRBuilder<> ThenIRB(ThenBlock);
          LoadInst* L = ThenIRB.CreateLoad(GEP);
          L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
          FunctionModified |= dumpVariable(ThenIRB, field_name, field_meta, static_cast<Value*>(L), false, name, true, depth+1);

          IRBuilder<> ElseIRB(ElseBlock);
	        FunctionModified |= dumpVariableNosense(ElseIRB, field_name, field_meta, T, depth+1);
		      
			    break;
        }
		    default:
			    break;
	    }
      
      if (IsPtr) {
      
        LoadInst* L = IRB.CreateLoad(GEP);
        L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        FunctionModified |= dumpVariable(IRB, field_name, field_meta, static_cast<Value*>(L), false, name, true, depth+1);
        
      }

    }
    
    FunctionModified = true;
  
  }

  return FunctionModified;

}

bool DaikonInstruments::dumpVariable(IRBuilder<>& IRB, const std::string& name, MDNode* meta, Value* V, bool isParam, std::string parent, bool isPtr, int depth) {

  bool FunctionModified = false;
  Type *T = V->getType();
  
 	switch (T->getTypeID()) {
	  case Type::IntegerTyID: {
	    TypeSize BitsNum = T->getPrimitiveSizeInBits();
	    if (BitsNum > 64) break;
	    
	    size_t SizeIndex = TypeSizeToSizeIndex(BitsNum);
	    
	    decls << "      {\"name\": \"" << name << "\", \"type\": \"" << "i" << BitsNum << "\", \"kind\": ";
	    if (parent.size() == 0) {
        if (isParam) decls << "\"param\"},\n";
        else decls << "\"var\"},\n";
	    } else
	      decls << "\"field\", \"parent\": \"" << parent << "\"},\n";
	    
	    Value *N = IRB.CreateGlobalStringPtr(name);
	    Value *I = IRB.CreateBitCast(V, IntTypeSized[SizeIndex]);
	    CallInst* CI = IRB.CreateCall(daikonDumpSignedIntFns[SizeIndex], ArrayRef<Value*>{N, I});
	    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
	    
	    FunctionModified = true;
	    break;
	  }
	  case Type::FloatTyID: {
	  
	    decls << "      {\"name\": \"" << name << "\", \"type\": \"" << "float" << "\", \"kind\": ";
	    if (parent.size() == 0) {
        if (isParam) decls << "\"param\"},\n";
        else decls << "\"var\"},\n";
	    } else
	      decls << "\"field\", \"parent\": \"" << parent << "\"},\n";
	  
	    Value *N = IRB.CreateGlobalStringPtr(name);
	    Value *I = IRB.CreateBitCast(V, FloatTy);
	    CallInst* CI = IRB.CreateCall(daikonDumpFloatFn, ArrayRef<Value*>{N, I});
	    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
	    
	    FunctionModified = true;
	    break;
    }
	  case Type::DoubleTyID: {
	  
	    decls << "      {\"name\": \"" << name << "\", \"type\": \"" << "double" << "\", \"kind\": ";
      if (parent.size() == 0) {
        if (isParam) decls << "\"param\"},\n";
        else decls << "\"var\"},\n";
      } else
        decls << "\"field\", \"parent\": \"" << parent << "\"},\n";
	  
	    Value *N = IRB.CreateGlobalStringPtr(name);
	    Value *I = IRB.CreateBitCast(V, DoubleTy);
	    CallInst* CI = IRB.CreateCall(daikonDumpDoubleFn, ArrayRef<Value*>{N, I});
	    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

	    FunctionModified = true;
	    break;
    }
	  case Type::ArrayTyID:
	  // case Type::VectorTyID: 
		break;

	  default:
		  break;
  }

  if(StructType *ST = dyn_cast<StructType>(T)) {
  
    std::string structname;
    if (ST->hasName()) structname = ST->getName().str();
    else structname = "<anon>";
  
    decls << "      {\"name\": \"" << name << "\", \"type\": \"" << structname << "\", \"kind\": ";
	    if (parent.size() == 0) {
        if (isParam) decls << "\"param\"},\n";
        else decls << "\"var\"},\n";
	    } else
	      decls << "\"field\", \"parent\": \"" << parent << "\"},\n";
    
    // TODO flag notnull in decls, still print address, now this is never called and it is broken

    if (depth < MAX_DEPTH)
      FunctionModified |= dumpStructure(IRB, name, meta, ST, V, depth);
  
  } else if(PointerType* PT = dyn_cast<PointerType>(T)) {

    Type* ET = PT->getElementType();
    if(StructType* ST = dyn_cast<StructType>(ET)) {
    
      std::string structname;
      if (ST->hasName()) structname = ST->getName().str();
      else structname = "<anon>";
      
      decls << "      {\"name\": \"" << name << "\", \"type\": \"" << structname << "\", \"kind\": ";
	    if (parent.size() == 0) {
        if (isParam) decls << "\"param\"},\n";
        else decls << "\"var\"},\n";
	    } else
	      decls << "\"field\", \"parent\": \"" << parent << "\"},\n";
	    
	    size_t SizeIndex = TypeSizeToSizeIndex(LongSize);
	    Value *N = IRB.CreateGlobalStringPtr(name);
      Value *I = IRB.CreatePtrToInt(V, IntTypeSized[SizeIndex]);
	    
	    if (!isPtr) {
	    
	      // TODO flag notnull in decls
	    
	      CallInst* CI = IRB.CreateCall(daikonDumpSignedIntFns[SizeIndex], ArrayRef<Value*>{N, I});
	      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
	      
	      if (depth < MAX_DEPTH)
	        FunctionModified |= dumpStructure(IRB, name, meta, ST, V, depth);
      
      } else {
	      
	      uint32_t AllocSize;
        if (ST->isSized()) AllocSize = M.getDataLayout().getTypeAllocSize(ST);
        else AllocSize = 32; // an hard guess
        Value *Zero = ConstantInt::get(IntTypeSized[SizeIndex], 0, true);
        Value *ZeroI8 = ConstantInt::get(Int8Ty, 0, true);
        
        Instruction* Cmp1 = IRB.Insert(new ICmpInst(ICmpInst::ICMP_EQ, I, Zero));
        Instruction* ThenBlock1, *ElseBlock1;
        IRBSplitBlockAndInsertIfThenElse(IRB, Cmp1, Cmp1->getNextNode(), &ThenBlock1, &ElseBlock1);
        
        IRBuilder<> ThenIRB1(ThenBlock1);
        CallInst* CI1 = ThenIRB1.CreateCall(daikonDumpSignedIntFns[SizeIndex], ArrayRef<Value*>{N, Zero});
        CI1->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        
	      if (depth < MAX_DEPTH)
	        FunctionModified |= dumpStructureNosense(ThenIRB1, name, meta, ST, depth);
        
        IRBuilder<> ElseIRB1(ElseBlock1);

        Value *Ptr = ElseIRB1.CreateBitCast(V, Int8PTy);
        Value *SizeVal = ConstantInt::get(IntTypeSized[SizeIndex], AllocSize, true);
        
        Instruction* IsMap = ElseIRB1.CreateCall(daikonAreaIsMappedFn, ArrayRef<Value*>{Ptr, SizeVal});
        IsMap->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        Instruction* Cmp2 = ElseIRB1.Insert(new ICmpInst(ICmpInst::ICMP_NE, IsMap, ZeroI8));

        Instruction* ThenBlock2, *ElseBlock2;
        IRBSplitBlockAndInsertIfThenElse(ElseIRB1, Cmp2, Cmp2->getNextNode(), &ThenBlock2, &ElseBlock2);

        IRBuilder<> ThenIRB2(ThenBlock2);
        CallInst* CI2 = ThenIRB2.CreateCall(daikonDumpSignedIntFns[SizeIndex], ArrayRef<Value*>{N, I});
        CI2->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        if (depth < MAX_DEPTH)
          FunctionModified |= dumpStructure(ThenIRB2, name, meta, ST, V, depth);

        IRBuilder<> ElseIRB2(ElseBlock2);
	      CallInst* CI3 = ElseIRB2.CreateCall(daikonDumpNosenseFn, ArrayRef<Value*>{N});
	      CI3->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
	      if (depth < MAX_DEPTH)
	        FunctionModified |= dumpStructureNosense(ElseIRB2, name, meta, ST, depth);
      
      }

    }

  }

  return FunctionModified;

}

bool DaikonInstruments::iterArguments(IRBuilder<>& IRB) {

  bool FunctionModified = false;

  for(Function::arg_iterator it = F.arg_begin(); it != F.arg_end(); ++it) {
		Argument *A = &*it;
		Value *V = static_cast<Value*>(A);
    
    std::string name;
    MDNode *meta = nullptr;
    if (V->hasName()) {
      name = V->getName().str();
      for (auto LV : DbgVars) {
        if (LV->getArg() && LV->getName().str() == name)
          meta = LV;
      }
    } else
      name = "arg" + std::to_string(A->getArgNo());

    FunctionModified |= dumpVariable(IRB, name, meta, V, true);
    
	}
	
	return FunctionModified;

}

bool DaikonInstruments::instrumentFunction() {

  bool FunctionModified = false;

  if (F.isVarArg() || isBlacklisted(&F)) return FunctionModified; // not supported
  
  decls.open(daikon_output_path + "/" + funcname + "_decls.literal.part");
  assert (decls.good());
  
  // get which structure type is used and which fields
  std::map<Value*, std::string> declAllocas;
  std::map<Value*, Value*> declCalls;
  
  std::vector<Instruction*> returnInsts;
  
  Value *ZeroI8 = ConstantInt::get(Int8Ty, 0, true);
  
  hasCalls = false;
  
  for (auto &BB : F) {
    for (auto &Inst : BB) {
      if(GetElementPtrInst* GEP = dyn_cast<GetElementPtrInst>(&Inst)) {

        Type* ST = GEP->getSourceElementType();
        
        if(isa<StructType>(ST)) {
        } else if(PointerType* PT = dyn_cast<PointerType>(ST)) {

          Type* ET = PT->getElementType();
          if(StructType* PST = dyn_cast<StructType>(ET))
            ST = PST;

        } else
          continue;
        
        if (GEP->hasIndices()) {

          auto Idx = GEP->idx_begin();
          ++Idx;
          if (Idx != GEP->idx_end() && isa<ConstantInt>(&*Idx)) {
            ConstantInt *CI = dyn_cast<ConstantInt>(&*Idx);
            usedFields[ST].insert(CI->getZExtValue());
          }

        }

      } if (DbgDeclareInst* DbgDeclare = dyn_cast<DbgDeclareInst>(&Inst)) {

        //declCalls[DbgDeclare] = DbgDeclare->getAddress();
        //declAllocas[DbgDeclare->getAddress()] = DbgDeclare->getVariable()->getName();
        
        MDNode* meta = DbgDeclare->getVariable();
        if (DILocalVariable* LV = dyn_cast<DILocalVariable>(meta)) {
          DbgVars.push_back(LV);
        }

      } else if (DbgValueInst* DbgValue = dyn_cast<DbgValueInst>(&Inst)) {

        //declCalls[DbgValue->getValue()] = DbgValue->getVariable()->getName();
        
        MDNode* meta = DbgValue->getVariable();
        if (DILocalVariable* LV = dyn_cast<DILocalVariable>(meta)) {
          DbgVars.push_back(LV);
        }

      } else if (CallInst* CI = dyn_cast<CallInst>(&Inst)) {

        hasCalls = true;
        for(auto it = CI->arg_begin(); it != CI->arg_end(); ++it) {
          Value *V = it->get();
          usedForCalls[V->getType()] = true;
        }
        
      } else if(ReturnInst* RI = dyn_cast<ReturnInst>(&Inst)) {

        returnInsts.push_back(&Inst);
      
      }
    }
  }
  
  DITypeRefArray ArgsMeta = static_cast<DISubroutineType*>(F.getSubprogram()->getType())->getTypeArray();
  
  IRBuilder<> IRB(&*F.getEntryBlock().getFirstInsertionPt());
  
  CallInst* CI = IRB.CreateCall(daikonDumpLockFn);
  CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
  
  decls << "{\n  \"name\": \"" << funcname << "\",\n";
  decls << "  \"ppts\": {\n    \"ENTER\": [\n";
  
  Value *N = IRB.CreateGlobalStringPtr(funcname);
  CallInst *InvNonce = IRB.CreateCall(daikonDumpEnterPrologueFn, ArrayRef<Value*>{N});
  InvNonce->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

  FunctionModified |= iterArguments(IRB);
  
  decls << "    ],\n";
  
  CI = IRB.CreateCall(daikonDumpEpilogueFn);
  CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
  
  CI = IRB.CreateCall(daikonDumpUnlockFn);
  CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

  size_t exit_num = 0;
  for (auto Inst : returnInsts) {
   
    IRBuilder<> IRBExit(Inst);

    if (exit_num > 0)
      decls << ",\n";
    decls << "    \"EXIT" << exit_num << "\": [\n";
    
    CI = IRBExit.CreateCall(daikonDumpLockFn);
    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
    Value *I = ConstantInt::get(Int32Ty, exit_num, true);
    CI = IRBExit.CreateCall(daikonDumpExitPrologueFn, ArrayRef<Value*>{N, I, InvNonce});
    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));

    exit_num++;

    FunctionModified |= iterArguments(IRBExit);
    ReturnInst* RI = static_cast<ReturnInst*>(Inst);
    Value* RV = RI->getReturnValue();
    if (RV) {
      MDNode *RMeta = nullptr;
      if (ArgsMeta.size() > 0) RMeta = ArgsMeta[0];
      dumpVariable(IRBExit, "<retval>", RMeta, RV, false);
    }
    
    decls << "    ]";
    
    CI = IRBExit.CreateCall(daikonDumpEpilogueFn);
    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
    CI = IRBExit.CreateCall(daikonDumpUnlockFn);
    CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    
  }
  
  decls << "\n  }\n},\n";

  /*
  unsigned loop_num = 0;
  // max 2 levels of subloops
  std::vector< std::pair<Loop*, unsigned> > LL;
  for (Loop* L : LI) {
    LL.push_back(std::make_pair(L, loop_num++));
    for (Loop* L1 : L->getSubLoops()) {
      LL.push_back(std::make_pair(L1, loop_num++));
      for (Loop* L2 : L1->getSubLoops()) {
        LL.push_back(std::make_pair(L2, loop_num++));
      }
    }
  }
  
  std::vector<Value*> loopGuards;  
  for (unsigned i = 0; i < loop_num; ++i) {
    loopGuards.push_back(IRB.CreateAlloca(Int8Ty));
  }
  
  unsigned loop_cnt = 0;
  for (Loop* L : LI) {
    if (loopGuards[loop_cnt]) {
      StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
      S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
    }
    ++loop_cnt;
    
    for (BasicBlock *BB : L->getBlocks()) {
      IRBuilder IRB(BB->getFirstNonPHIOrDbg());
      
      for (Loop* L1 : L->getSubLoops()) {
        if (loopGuards[loop_cnt]) {
          StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
          S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        }
        ++loop_cnt;
        
        for (BasicBlock *BB : L1->getBlocks()) {
          IRBuilder IRB(BB->getFirstNonPHIOrDbg());
          
          for (Loop* L2 : L1->getSubLoops()) {

            if (loopGuards[loop_cnt]) {
              StoreInst* S = IRB.CreateStore(ZeroI8, loopGuards[loop_cnt]);
              S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            }
            ++loop_cnt;

          }
          
          break;
        }
      }

      break;
    }
  }
  
  for (auto& LP : LL) {
  
    Loop* L = LP.first;
    
    usedFields.clear();
    usedForCalls.clear();
    structTypes.clear();
  
    //errs() << *L << "\n";
    std::map<Value*, bool> Used;
  
    for (BasicBlock *BB : L->getBlocks()) {
      for (auto &Inst : *BB) {
      
        // to avoid Instruction does not dominate all uses!
        if (declAllocas.find(&Inst) != declAllocas.end()) {
          Used[&Inst] = false;
          continue;
        }
        if (declCalls.find(&Inst) != declCalls.end()) {
          Used[declCalls[&Inst]] = false;
          continue;
        }
        
        for (auto op = Inst.op_begin(); op != Inst.op_end(); ++op) {
          Value* V = op->get();
          if (declAllocas.find(V) != declAllocas.end()) {
            // used in loop
            if (Used.find(V) == Used.end())
              Used[V] = true;
          }
        }
      
      }
    }
    
    for (auto& Pair : Used) {
      if (Pair.second) {
        Type *T = Pair.first->getType();

        if(StructType* ST = dyn_cast<StructType>(T)) {

          structTypes.push_back(ST);

        } else if(PointerType* PT = dyn_cast<PointerType>(T)) {

          Type* ET = PT->getElementType();
          if(StructType* ST = dyn_cast<StructType>(ET))
            structTypes.push_back(ST);

        }
      }
    }
    
    for (BasicBlock *BB : L->getBlocks()) {
      for (auto &Inst : *BB) {
      
        if(GetElementPtrInst* GEP = dyn_cast<GetElementPtrInst>(&Inst)) {

          Type* ST = GEP->getSourceElementType();
          if (GEP->hasIndices() &&
              std::find(structTypes.begin(), structTypes.end(), ST) != structTypes.end()) {

            auto Idx = GEP->idx_begin();
            ++Idx;
            if (Idx != GEP->idx_end()) {
              ConstantInt *CI = dyn_cast<ConstantInt>(&*Idx);
              usedFields[ST].insert(CI->getZExtValue());
            }

          }

          // if a nested structure is returned, add it to the types to monitor
          Type* RT = GEP->getResultElementType();
          if(StructType* ST = dyn_cast<StructType>(RT)) {

            structTypes.push_back(ST);

          } else if(PointerType* PT = dyn_cast<PointerType>(RT)) {

            Type* ET = PT->getElementType();
            if(StructType* ST = dyn_cast<StructType>(ET))
              structTypes.push_back(ST);

          }

        } if (DbgDeclareInst* DbgDeclare = dyn_cast<DbgDeclareInst>(&Inst)) {

          // Do nothing

        } else if (CallInst* CI = dyn_cast<CallInst>(&Inst)) {

          for(auto it = CI->arg_begin(); it != CI->arg_end(); ++it) {
            Value *V = it->get();
            usedForCalls[V->getType()] = true;
          }
          
        }
      
      }
    }
    
    for (BasicBlock *BB : L->getBlocks()) {
      Instruction* First = BB->getFirstNonPHIOrDbg();
       
      std::string loop_name = funcname + "###loop" + std::to_string(LP.second);
      decls << "{\n  \"name\": \"" << loop_name << "\",\n";
      decls << "  \"ppts\": {\n    \"ENTER\": [\n";
      
      IRBuilder<> IRBLoopFirst(First);
      
      LoadInst* LGL = IRBLoopFirst.CreateLoad(loopGuards[LP.second]);
      LGL->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      Instruction* Cmp = IRBLoopFirst.Insert(new ICmpInst(ICmpInst::ICMP_NE, LGL, ZeroI8));

      Instruction* ThenBlock, *ElseBlock;
      IRBSplitBlockAndInsertIfThenElse(IRBLoopFirst, Cmp, Cmp->getNextNode(), &ThenBlock, &ElseBlock);

      IRBuilder<> IRBLoop(ThenBlock);
      IRBuilder<> IRBFirst(ElseBlock);
      
      StoreInst* S = IRBFirst.CreateStore(ConstantInt::get(Int8Ty, 1, true), loopGuards[LP.second]);
      S->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      Value *LN = IRBLoop.CreateGlobalStringPtr(loop_name);
      CallInst *InvNonce = IRBLoop.CreateCall(daikonDumpEnterPrologueFn, ArrayRef<Value*>{LN});
      InvNonce->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      std::set<std::string> Visited;
      for (auto UP : Used) {
      
        if (!UP.second) continue;
        Value *V = UP.first;
        
        if (Visited.find(declAllocas[V]) != Visited.end()) continue;
        Visited.insert(declAllocas[V]);
      
        if (AllocaInst* AI = dyn_cast<AllocaInst>(V)) {
        
          //errs() << *V << "       " << *V->getType() << "\n";
          Type* T = V->getType();
          PointerType* PT = dyn_cast<PointerType>(T);
          Type* ET = PT->getElementType();
          
          if (!isInterestingType(ET)) continue;
          if (!ET->isSized()) continue;
          
          // TODO check here __daikon_area_is_mapped
          
		      size_t SizeIndex = TypeSizeToSizeIndex(LongSize);
		      uint32_t AllocSize = M.getDataLayout().getTypeAllocSize(ET);
		      
		      Value *Ptr = IRBLoop.CreateBitCast(AI, Int8PTy);
          Value *SizeVal = ConstantInt::get(IntTypeSized[SizeIndex], AllocSize, true);
		      
		      Instruction* Cmp;
		      if(StructType* ST = dyn_cast<StructType>(ET)) {
		      
		        // TODO check partial validity
		        Instruction* IsMap = IRBLoop.CreateCall(daikonAreaIsMappedFn, ArrayRef<Value*>{Ptr, SizeVal});
            IsMap->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            Cmp = IRBLoop.Insert(new ICmpInst(ICmpInst::ICMP_NE, IsMap, ZeroI8));
		      
		      } else {
		      
		        Instruction* IsValid = IRBLoop.CreateCall(daikonAreaIsValidFn, ArrayRef<Value*>{Ptr, SizeVal});
            IsValid->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            Cmp = IRBLoop.Insert(new ICmpInst(ICmpInst::ICMP_NE, IsValid, ZeroI8));
		      
          }

          Instruction* ThenBlock, *ElseBlock;
          IRBSplitBlockAndInsertIfThenElse(IRBLoop, Cmp, Cmp->getNextNode(), &ThenBlock, &ElseBlock);

          IRBuilder<> ThenIRB(ThenBlock);
          IRBuilder<> ElseIRB(ElseBlock);
          
          if(StructType* ST = dyn_cast<StructType>(ET)) {
          
            FunctionModified |= dumpVariable(ThenIRB, declAllocas[V], V, false);
            
            FunctionModified |= dumpVariableNosense(ElseIRB, declAllocas[V], T);
          
          } else {
          
            LoadInst* L = ThenIRB.CreateLoad(AI);
            L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            FunctionModified |= dumpVariable(ThenIRB, declAllocas[V], L, false);
            
            FunctionModified |= dumpVariableNosense(ElseIRB, declAllocas[V], ET);
          
          }
        
        }
      }
      
      CallInst *CI = IRBLoop.CreateCall(daikonDumpEpilogueFn);
      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      decls << "    ],\n    \"EXIT0\": [\n";
      
      Value *I = ConstantInt::get(Int32Ty, 0, true);
      CI = IRBLoop.CreateCall(daikonDumpExitPrologueFn, ArrayRef<Value*>{LN, I, InvNonce});
      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
      
      // insert again to make Daikon happy
      // TODO do not duplicate code
      Visited.clear();
      for (auto UP : Used) {
      
        if (!UP.second) continue;
        Value *V = UP.first;
        
        if (Visited.find(declAllocas[V]) != Visited.end()) continue;
        Visited.insert(declAllocas[V]);
      
        if (AllocaInst* AI = dyn_cast<AllocaInst>(V)) {
        
          //errs() << *V << "       " << *V->getType() << "\n";
          Type* T = V->getType();
          PointerType* PT = dyn_cast<PointerType>(T);
          Type* ET = PT->getElementType();
          
          if(StructType* ST = dyn_cast<StructType>(ET)) {
          
            // TODO
            // dumpVariable(IRBLoop, declAllocas[V], V, false);
          
          } else if (isInterestingType(ET)) {
          
            LoadInst* L = IRBLoop.CreateLoad(AI);
            L->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
            dumpVariable(IRBLoop, declAllocas[V], L, false);
          
          }
        
        }
      }
      
      decls << "    ]\n  }\n},\n";
      
      CI = IRBLoop.CreateCall(daikonDumpEpilogueFn);
      CI->setMetadata(M.getMDKindID("nosanitize"), MDNode::get(*C, None));
        
      break;
    }
    
    loop_num++;

  }*/
  
  decls.close();
  
  /*for (auto &BB : F)
  for (auto &I : BB)
  if (I.getParent() != &BB) {
  
    errs() << "ERROR " << I << "\n";
    errs() << "PARENT " << *I.getParent() << "\n";
    errs() << "BB " << BB << "\n";
  
  }*/
  
  return FunctionModified;
	
}

bool DaikonInstruments::isInterestingType(Type *T) {

	switch (T->getTypeID()) {
		case Type::IntegerTyID:
		case Type::FloatTyID:
		case Type::DoubleTyID:
		// case Type::ArrayTyID:
		// case Type::VectorTyID: 
			return true;

		default:
			break;
	}
	
	if(StructType *ST = dyn_cast<StructType>(T)) {
  
    return true;
  
  } else if(PointerType* PT = dyn_cast<PointerType>(T)) {

    Type* ET = PT->getElementType();
    if(StructType* ST = dyn_cast<StructType>(ET))
      return true;

  }
	
	return false;

}

class DaikonFunctionPass : public FunctionPass {
public:
  static char ID;

  explicit DaikonFunctionPass() : FunctionPass(ID) {}

  void getAnalysisUsage(AnalysisUsage &AU) const override {
    AU.setPreservesCFG();
    AU.addRequired<LoopInfoWrapperPass>();
  }

  StringRef getPassName() const override {
    return "DaikonFunctionPass";
  }

  bool runOnFunction(Function &F) override {
    Module &M = *F.getParent();
    LoopInfo &LI = getAnalysis<LoopInfoWrapperPass>().getLoopInfo();
    DaikonInstruments DI(M, F, LI);
    bool r = DI.instrumentFunction();
    verifyFunction(F);
    return r;
  }
};


char DaikonFunctionPass::ID = 0;

static void registerDaikonPass(const PassManagerBuilder &,
                               legacy::PassManagerBase &PM) {

  PM.add(new DaikonFunctionPass());

}

static RegisterStandardPasses RegisterDaikonPass(
    PassManagerBuilder::EP_OptimizerLast, registerDaikonPass);

static RegisterStandardPasses RegisterDaikonPass0(
    PassManagerBuilder::EP_EnabledOnOptLevel0, registerDaikonPass);

static RegisterPass<DaikonFunctionPass>
    X("daikon-func", "DaikonFunctionPass",
      false,
      false
    );

