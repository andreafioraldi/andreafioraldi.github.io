#define _GNU_SOURCE
#include <cstdlib>
#include <cstdio>
#include <cmath>
#include <mutex>
#include <cstdint>
#include <sys/mman.h>
#include <unistd.h>
#include <fcntl.h>
#include <inttypes.h>
#include <dlfcn.h>

#include "daikon_dump.h"

using namespace std;

extern "C" {

int __daikon_out_fd;
typeof(&write) __daikon_real_write;

int __daikon_printf(const char* format, ...);

//void *__asan_region_is_poisoned(void *beg, size_t size);
intptr_t __msan_test_shadow(const volatile void *x, size_t size);
void __msan_unpoison_string(const volatile char *a);
void __msan_unpoison(const volatile void *a, size_t size);

}

namespace __daikon {


__attribute__((constructor, no_sanitize("address", "memory"))) void init() {
  __daikon_real_write = (typeof(&write))dlsym(RTLD_NEXT, "write");
  if (getenv("DAIKON_DTRACE_FILE")) {
    char* path = getenv("DAIKON_DTRACE_FILE");
    __daikon_out_fd = open(path, O_WRONLY | O_CREAT | O_TRUNC, 0666);
  } else
    __daikon_out_fd = 2;
}

} // namespace __daikon

using namespace __daikon;

extern "C" __attribute__((no_sanitize("address", "memory"))) uint8_t __daikon_area_is_mapped(void *ptr, size_t len) {

  if ((uintptr_t)ptr < sysconf(_SC_PAGE_SIZE)) return 0; // fast path for null ptrs
  
  // check if mapped
  char *p = (char*)ptr;
  char *page = (char *)((uintptr_t)p & ~(sysconf(_SC_PAGE_SIZE) - 1));

  int r = msync(page, (p - page) + len, MS_ASYNC);
  if (r < 0) return errno != ENOMEM;
  
  if (__msan_test_shadow(ptr, len) == -1)
    return 1;

  size_t i = 0;
  while (__msan_test_shadow((char*)ptr + i, len) == 0 && i < len) {
    i++;
  }
  
  if (i == len) return 0; // full poisoned
  return 1;

}

extern "C" __attribute__((no_sanitize("address", "memory"))) uint8_t __daikon_area_is_valid(void *ptr, size_t len) {

  // check if valid
  // return __asan_region_is_poisoned(ptr, len) == NULL;
  return __msan_test_shadow(ptr, len) == -1;

}

static mutex dump_mutex;
static size_t this_invocation_nonce;

extern "C" __attribute__((no_sanitize("address", "memory"))) size_t __daikon_dump_enter_prologue(const char* name) {
  size_t in = this_invocation_nonce++;
  if (in == 0) {
    __daikon_printf("input-language C/C++\ndecl-version 2.0\n"
                        "var-comparability none\n\n");
  }
  __daikon_printf("%s():::ENTER\n", name);
  __daikon_printf("this_invocation_nonce\n%lu\n", in);
  return in;
}

extern "C" __attribute__((no_sanitize("address", "memory"))) size_t __daikon_dump_loop_prologue(const char* name, int pptid) {
  size_t in = this_invocation_nonce++;
  __daikon_printf("%s():::LOOP%d\n", name, pptid);
  __daikon_printf("this_invocation_nonce\n%lu\n", in);
  return in;
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_exit_prologue(const char* name, int pptid, size_t in) {
  __daikon_printf("%s():::EXIT%d\n", name, pptid);
  __daikon_printf("this_invocation_nonce\n%lu\n", in);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_epilogue() {
  __daikon_printf("\n");
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_lock() {
  dump_mutex.lock();
}
extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_unlock() {
  dump_mutex.unlock();
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_nosense(const char* name) {
  __daikon_printf("%s\nnonsensical\n2\n", name);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_i8(const char* name, int8_t val) {
  __daikon_printf("%s\n%d\n1\n", name, (int)val);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_i16(const char* name, int16_t val) {
  __daikon_printf("%s\n%d\n1\n", name, (int)val);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_i32(const char* name, int32_t val) {
  __daikon_printf("%s\n%d\n1\n", name, val);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_i64(const char* name, int64_t val) {
  __daikon_printf("%s\n%lld\n1\n", name, val);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_f(const char* name, float val) {
  __daikon_printf("%s\n%f\n1\n", name, val);
}

extern "C" __attribute__((no_sanitize("address", "memory"))) void __daikon_dump_d(const char* name, double val) {
  __daikon_printf("%s\n%f\n1\n", name, val);
}
