import argparse
import ast
import sys
import os

DESCR = "Reconstruct decls file"
opt = argparse.ArgumentParser(description=DESCR, formatter_class=argparse.RawTextHelpFormatter)
opt.add_argument("-i", action='store', required=True)
args = opt.parse_args()

with open(args.i) as f:
    body = f.read()

def get_type(t):
    if t.startswith("i"): return "int"
    if t in ("float", "double"): return t
    return "hashcode"

def get_kind(v):
    if v["kind"] in ("param", "var"): return "variable"
    elif v["kind"] == "field":
        return "field " + v["name"].split(".")[-1]

structs = {}

print("""input-language C/C++
decl-version 2.0
var-comparability none
""")

funcs = ast.literal_eval(body)
for fun in funcs:
    for ppt in fun["ppts"]:
        v_types = {}
        print("ppt " + fun["name"] + "():::" + ppt)
        if ppt == "ENTER":
            print("ppt-type enter")
        else:
            print("ppt-type subexit")
        for v in fun["ppts"][ppt]:
            v_types[v["name"]] = v["type"]
            print("variable " + v["name"])
            print("  var-kind " + get_kind(v))
            print("  dec-type " + v["type"])
            print("  rep-type " + get_type(v["type"]))
            if v["kind"] == "param":
                print("  flags is_param")
            if v["kind"] == "field":
                #print("  parent parent " + v["parent"] + ":::OBJECT 1")
                print("  enclosing-var " + v["parent"])
                cl = v_types[v["parent"]]
                if cl != "<anon>":
                    structs[cl] = structs.get(cl, {})
                    field_name = v["name"].split(".")[-1]
                    structs[cl][field_name] = v["type"]
        print()

for name in structs:
    print("ppt %s:::OBJECT" % name)
    print("ppt-type object")
    for v in structs[name]:
        print("variable " + v)
        print("  var-kind variable")
        print("  dec-type " + structs[name][v])
        print("  rep-type " + get_type(structs[name][v]))
    print()


