
def parse(dtrace):
    dtrace = dtrace[4:] # header
    i = 0
    ppts = {}
    while i < len(dtrace):
        ppt = dtrace[i].strip()
        if ppt.endswith(":::ENTER")
            pptype = 0
        else:
            pptype = 1
        ppt = ppt[:ppt.rfind(":::")]
        inv = dtrace[i+2].strip()
        j = i+3
        block = set()
        while dtrace[j].strip() != "":
            name = dtrace[j].strip()
            val = dtrace[j+1].strip()
            n = dtrace[j+2].strip()
            block.add((name, val, n))
            j += 3
        ppts[ppt] = ppts.get(ppt, {})
        ppts[ppt][inv] = ppts[ppt].get(inv, [None, None])
        ppts[ppt][inv][pptype] = block
    
    
        
    


