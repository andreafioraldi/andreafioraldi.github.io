
#include <pass.h>

using namespace llvm;

#define DEBUG_TYPE "FuncStats"
#define FuncStatsPassLog(M) LLVM_DEBUG(dbgs() << "FuncStatsPass: " << M << "\n")
#define oprint(s) outs() << s << "\n"

static cl::opt<bool>
DumpCalls("dump-calls",
    cl::desc("Dump all non unique calls"),
    cl::init(false), cl::NotHidden);

static cl::opt<bool>
DumpGraph("dump-graph",
    cl::desc("Dump the Call Graph"),
    cl::init(false), cl::NotHidden);

namespace {

  class FuncStatsPass : public ModulePass {

  public:
    static char ID;
    FuncStatsPass() : ModulePass(ID) {}

    virtual bool runOnModule(Module &M) {
      int num_funcs = 0;
      int total_BB = 0;
      std::map<Function*, int> callsToFunc;
      for (auto &F : M.getFunctionList()) {
        if (F.isDeclaration())
          continue;
        ++num_funcs;
        if (DumpGraph) {
          oprint("Call graph node for function: '" << F.getName() << "'");
        }
        for(auto &BB: F) {
          ++total_BB;
          if (DumpCalls || DumpGraph) {
            for (auto &I : BB) {

              CallSite CS(&I);
              if (!CS.getInstruction() || CS.isInlineAsm())
                continue;

              Function *Called = dyn_cast<Function>(CS.getCalledValue()->stripPointerCasts());
              if (!Called || Called->isDeclaration() || Called->isIntrinsic()) continue;
              callsToFunc[Called]+=1;
              if (DumpGraph) {
                oprint("    " << F.getName() << " calls function '" << Called->getName() << "'");
              }
            }
          }
        }
      }

      oprint("Num functions: " << num_funcs);
      oprint("Num BBs      : " << total_BB);

      if (DumpCalls) {
        for (auto elem: callsToFunc) {
          Function* F = elem.first;
          int calls   = elem.second;
          if (calls > 1) oprint(F->getName().str() << ": " << calls);
        }
      }

      return false;
    }
  };

}

char FuncStatsPass::ID = 0;
RegisterPass<FuncStatsPass> MP("func-stats", "FuncStats Pass");

