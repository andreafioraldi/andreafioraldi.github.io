
#include <pass.h>
#include <iostream>
#include <fstream>

using namespace llvm;

#define DEBUG_TYPE "DumpExtlib"
#define DumpExtlibPassLog(M) LLVM_DEBUG(dbgs() << "DumpExtlibPass: " << M << "\n")
#define oprint(s) (outs() << s << "\n")

static cl::list<std::string>
Whitelist("dumpext-whitelist",
    cl::desc("Specify the comma-separated path regexes for the whitelist"),
    cl::OneOrMore, cl::CommaSeparated, cl::NotHidden);

static cl::opt<std::string>
OutFilename("dumpext-out",
    cl::desc("Specify the name of the file where the function list will be saved [- for stdout]"),
    cl::init("-"), cl::NotHidden);

static cl::opt<bool>
Dbg("dumpext-dbg", cl::desc("Debug Mode"),
    cl::init(false));

namespace {
  // This pass tries to find in the module all the function that are identified
  // being part of linked static libraries.
  // It uses a really simple euristic where it takes a whitelist and assumes
  // a function being a library one if the DebugInfo of that function points to 
  // a path not containing any token in the whitelist.
  //
  // e.g. whitelist: curl
  // path: /src/curl/lib/    -> ok
  // path: /src/nghttp2/lib/ -> lib function
  //
  // The pass writes a function list to be passed to llvm-extract
  class DumpExtlibPass : public ModulePass {

  public:
    static char ID;
    DumpExtlibPass() : ModulePass(ID) {}

    std::string getFileDirectory(Function &F) {
        if (DISubprogram *Loc = F.getSubprogram()) {
            // StringRef File = Loc->getFilename();
            StringRef Directory = Loc->getDirectory();
            return Directory.str();
        } else {
            // oprint(F.getName());
            // assert(false);
            // No location metadata available
            return "";
        }
    }

    virtual bool runOnModule(Module &M) {

        // Initialize regular expressions for whitelist
        std::vector<Regex*> WhitelistRegexes;
        assert (!Whitelist.empty());
        passListRegexInit(WhitelistRegexes, Whitelist);

        std::vector<Function*> ToExtract;
        std::set<std::string> AllDirs;
        std::map<Function*, int> callsToFunc;

        // first remove all the aliases, since once we extract the functions we may invalidate some
        std::set<GlobalAlias*> aliasesToRemove;
        for (GlobalAlias &A: M.getAliasList()) {
            A.replaceAllUsesWith(A.getAliasee());
            aliasesToRemove.insert(&A);
        }
        for (GlobalAlias *A: aliasesToRemove) A->eraseFromParent();
        
        for (auto &F : M.getFunctionList()) {
            if (F.isDeclaration())
                continue;

            const std::string &DirName = getFileDirectory(F);

            // if the function does not have any debug info stay safe and assume
            // that it belongs to the original program
            if (DirName == "") continue;

            AllDirs.insert(DirName);

            // if the directory from where the function was compiled matches the
            // whitelist then do nothing 
            if (passListRegexMatch(WhitelistRegexes, DirName))
                continue;

            ToExtract.push_back(&F);
            if (Dbg) {
                oprint("Added " << F.getName().str() << ": " << DirName);
            }
        }

        std::string result = "";
        for (Function *F: ToExtract) {
            result.append(" -func=");
            // result.append("^");
            result.append(F->getName().str());
            // result.append("$|");
        }
        // result.replace(result.rfind("|"), 1, ")");

        if (OutFilename == "-") {
            outs() << result << "\n";
        } else {
            std::ofstream ofile;
            ofile.open(OutFilename, std::ios::out | std::ios::trunc);
            assert(ofile.is_open());

            ofile << result;
            ofile.flush();
            ofile.close();
        }
        return true;
    }
  };

}

char DumpExtlibPass::ID = 0;
RegisterPass<DumpExtlibPass> MP("dump-extlib", "DumpExtlib Pass");

