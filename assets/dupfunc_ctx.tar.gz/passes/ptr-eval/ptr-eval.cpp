
#include <pass.h>
#include "llvm/Analysis/CFG.h"
#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/CallGraphSCCPass.h"
#include "llvm/ADT/SCCIterator.h"
#include "WPA/WPAPass.h"
#include "WPA/FlowSensitive.h"
#include "SVF-FE/PAGBuilder.h"
#include <cgc_magics.h>
#include <cstdlib>
#include <sstream>
#include <iostream>
#include <fstream>
#include <chrono>

#include <SeaDsaWrapper.h>

using namespace llvm;
using namespace SVF;

#define DEBUG_TYPE "PointerEval"
#define PointerEvalPassLog(M) LLVM_DEBUG(dbgs() << "PointerEvalPass: " << M << "\n")
#define oprint(s) LLVM_DEBUG(outs() << s << "\n")
#define dprint(s) (outs() << s << "\n")

enum PointerStrategy {
  params, dataflow, dataflowSea
};

// The cloning strategy to follow when marking functions/calls to be cloned
cl::opt<PointerStrategy> Strategy("ptr-strategy", cl::desc("The Pointer strategy:"),
    cl::values(
        clEnumVal(params, "use params"),
        clEnumVal(dataflow, "use SVF"),
        clEnumVal(dataflowSea, "use sea-dsa")
    ),
    cl::init(params)
);

static cl::opt<std::string>
OutFilename("ptr-out",
    cl::desc("Specify the name of the file where the function list will be saved [- for stdout]"),
    cl::init("-"), cl::NotHidden);

namespace {
  // This pass marks which functions and which CallBases should be cloned by CGC
  // pass according to different strategies
  class PointerEvalPass : public ModulePass {

    // All the functions that should not be cloned, however planner can decide 
    // what to do with these functions
    std::set<Function*> FunctionBlacklist;

    // The number of times a function is originally called
    std::map<Function*, unsigned long> CallsToFunction;

    // Keep track of all the functions belonging to strongly connected components
    std::set<Function*> SCCFunctions;
    std::map<Function*, std::set<Function*>> FunctionToSCC;

    // A set of objects
    using ObjSet = std::set<const Value*>;

    // CallBase to an object set to which the params may point to
    using CallBase2ParamObjs = std::map<CallBase*, ObjSet>;

    // For each function, for each callbase, keep track of the object that the params may point to
    using Function2CallBaseParamObjs = std::map<Function*, CallBase2ParamObjs>;

    // the statistics we are gathering
    unsigned long nPointers = 0;
    unsigned long nObjects  = 0;
    std::list<unsigned long> objectsPerPointer;
    std::set<Instruction*> clonableCallBases;
    std::set<Instruction*> allCallBases;
    std::set<Function*> allFunctions;
    std::set<Function*> clonableFunctions;

    template <typename Iterator>
    std::string join(Iterator begin, Iterator end, char separator = '.')
    {
        std::ostringstream o;
        if(begin != end)
        {
            o << *begin++;
            for(;begin != end; ++begin)
                o  << separator << *begin;
        }
        return o.str();
    }

    template <typename Container>
    std::string join(Container const& c, char separator = '.')
    {
        using std::begin;
        using std::end;
        return join(begin(c), end(c), separator);
        // not using std::... directly:
        // there might be a non-std overload that wouldn't be found if we did
    }

    // Return true if `F` has an available_externally linkage (i.e. equivalent to a declaration)
    bool isAvailableExternally(Function &F) {
        GlobalValue::LinkageTypes L = F.getLinkage();
        return GlobalValue::isAvailableExternallyLinkage(L);
    }

    void setBlacklistedMetadata(Function &F) {
        LLVMContext& C = F.getContext();
        MDNode* N = MDNode::get(C, ConstantAsMetadata::get(ConstantInt::get(C, APInt(sizeof(unsigned long)*8, 1, true))));
        F.setMetadata(CGC_CLONE_NEVER, N);
    }

    // Simple static dataflow analysis from V to its users, collecting all the values
    // that may depend on V
    std::set<Value*> collectAllDependentValues(Value* V) {
        static std::map<Value*, std::set<Value*>> dependentValuesCache;

        if (dependentValuesCache.find(V) != dependentValuesCache.end()) {
            return dependentValuesCache[V];
        }

        std::set<Value*> &dependentValues = dependentValuesCache[V];
        std::list<Value *> toVisit;

        // initialize structs
        toVisit.push_back(V);
        dependentValues.insert(V);

        while (!toVisit.empty()) {
            Value *curr = toVisit.front();
            toVisit.pop_front();
            for (Value* user: curr->users()) {
                if (dependentValues.find(user) == dependentValues.end()) {
                    dependentValues.insert(user);
                    toVisit.push_back(user);
                }
            }

            // forward data flow through memory in a naive way
            if (StoreInst *SI = dyn_cast<StoreInst>(curr)) {
                // taint the pointer operand
                Value *ptr = SI->getPointerOperand();
                if (dependentValues.find(ptr) == dependentValues.end()) {
                    dependentValues.insert(ptr);
                    toVisit.push_back(ptr);
                }
            }
        }
        return dependentValues;
    }

    // Returns all allocation sites from which V might have originated in F.
    // Simple static dataflow analysis from V up to the values it depends on
    std::set<Value*>  getAllocSites(Value *V, const Function &F) {
        static std::map<Value*, std::set<Value*>> allocCache;

        if (allocCache.find(V) != allocCache.end()) {
            return allocCache[V];
        }

        std::set<Value*> &allocs = allocCache[V];
        std::list<Value *> toVisit;
        std::set<Value *> visited;

        // initialize structs
        toVisit.push_back(V);

        while (!toVisit.empty()) {
            Value *curr = toVisit.front();
            toVisit.pop_front();
            if (visited.find(curr) != visited.end()) continue;
            visited.insert(curr);

            if (isa<AllocaInst>(curr) || isa<GlobalValue>(curr)) {
                // Add alloca and globals
                allocs.insert(curr);
            } else if (isa<CallBase>(curr)) {
                // if it is a call, and it is a pointer type, assume is some sort
                // of allocation, and add it to the output
                if (!curr->getType()->isPointerTy()) continue;
                allocs.insert(curr);
            } else if (User *currU = dyn_cast<User>(curr)) {
                for (Value *operand: currU->operands()) {
                    toVisit.push_back(operand);
                }
            } else {
                // if it is not an instruction, may be an argument (or something else?)
                // add to the alloc sites
                // dprint(*curr);
                allocs.insert(curr);
            }
        }
        return allocs;
    }

    // Add all the objects that the params of CB may points-to, to `PossibleObjs`
    void collectParamObjects(CallBase *CB, ObjSet &PossibleObjs) {
        Function *F = CB->getFunction();
        allCallBases.insert(CB);
        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
        allFunctions.insert(Called);
        // collect all the possible target object of params passed by the callbase
        for (Value* arg: CB->args()) {
            if (!arg->getType()->isPointerTy()) continue;

            ++nPointers;
            clonableCallBases.insert(CB);
            clonableFunctions.insert(Called);

            unsigned long alloc_sites = 0;
            for (const Value* alloc: getAllocSites(arg, *F)) {
                // oprint("     A: " << *alloc);
                // add the object to the output
                PossibleObjs.insert(alloc);

                ++alloc_sites;
            }
            nObjects += alloc_sites;
            objectsPerPointer.push_back(alloc_sites);
        }
    }

    // Eval the custom pointer analysis
    void paramsEval(Module &M) {
        // keep track of all the object that may be passed from different callbases to the same function
        Function2CallBaseParamObjs ParamObjPerCallPerFunction;

        // collect all the objects accessed by fuctions given their calling context
        for (Function &F: M) {
            for (BasicBlock &BB: F) {
                for (Instruction &I: BB) {
                    // Search all call bases
                    if (CallBase * CB = dyn_cast<CallBase>(&I)) {

                        // Only if they represent direct calls to functions
                        if (CB->isInlineAsm()) continue;
                        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                        if (!Called || Called->isDeclaration() || isAvailableExternally(*Called) || Called->isIntrinsic()) continue;

                        // Collect the object the parameters may point-to
                        collectParamObjects(CB, ParamObjPerCallPerFunction[Called][CB]);
                    }
                }
            }
        }

        // print all the object for each function callsite
        // dumpPtsObjects(ParamObjPerCallPerFunction);
    }

    
    // Add all the objects that the params of CB may points-to, to `PossibleObjs`
    void collectSVFParamObjects(PointerAnalysis* pta, CallBase *CB, ObjSet &PossibleObjs) {
        assert(pta);
        allCallBases.insert(CB);
        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
        allFunctions.insert(Called);
        // collect all the possible target object of params passed by the callbase
        for (Value* arg: CB->args()) {
            if (!arg->getType()->isPointerTy()) continue;

            ++nPointers;
            clonableCallBases.insert(CB);
            clonableFunctions.insert(Called);

            unsigned long alloc_sites = 0;
            NodeID pNodeId = pta->getPAG()->getValueNode(arg);
            const NodeBS& pts = pta->getPts(pNodeId);
            for (NodeBS::iterator ii = pts.begin(), ie = pts.end(); ii != ie; ii++) {
                PAGNode* targetObj = pta->getPAG()->getPAGNode(*ii);

                // Ensure we do not deal with dummy or const objects
                if(!targetObj->hasValue()) continue;
                const Value* targetObjVal = targetObj->getValue();
                
                // add the object to the output
                PossibleObjs.insert(targetObjVal);
                ++alloc_sites;
            }
            nObjects += alloc_sites;
            objectsPerPointer.push_back(alloc_sites);
        }
    }

    // Add all the objects that the params of CB may points-to, to `PossibleObjs`
    void collectSeaParamObjects(SeaDsa* SDSA, CallBase *CB, ObjSet &PossibleObjs) {
        assert(SDSA);
        Function *F = CB->getFunction();
        allCallBases.insert(CB);
        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
        allFunctions.insert(Called);
        // collect all the possible target object of params passed by the callbase
        for (Value* arg: CB->args()) {
            if (!arg->getType()->isPointerTy()) continue;

            ++nPointers;
            clonableCallBases.insert(CB);
            clonableFunctions.insert(Called);
            if (SDSA->getCell(arg, *F) == nullptr) continue;

            unsigned long alloc_sites = 0;
            for (const Value* alloc: SDSA->getAllocSites(arg, *F)) {
                // oprint("     A: " << *alloc);
                // add the object to the output
                PossibleObjs.insert(alloc);
                ++alloc_sites;
            }
            nObjects += alloc_sites;
            objectsPerPointer.push_back(alloc_sites);
        }
    }

    void dumpPtsObjects(Function2CallBaseParamObjs &ParamObjPerCallPerFunction) {
        // recreate the map but using strings to have a sorted visit
        // super lazy inefficient way
        // std::map<llvm::Function *, std::map<llvm::CallBase *, std::set<const llvm::Value *>>> sorted;
        std::map   <std::string,      std::map<std::string,      std::set<      std::string>>> sorted;
        for (auto &pair: ParamObjPerCallPerFunction) {
            Function *F = pair.first;
            std::string FName = F->getName(); 
            CallBase2ParamObjs &callBase2Objs = pair.second;
            for (auto &pair: callBase2Objs) {
                CallBase *CB = pair.first;
                std::string CBStr;
                llvm::raw_string_ostream rso(CBStr);
                CB->print(rso);
                ObjSet &objs = pair.second;
                for (auto &obj: objs) {
                    // if global value the name is sufficient
                    if (isa<GlobalValue>(obj)) {
                        sorted[FName][CBStr].insert(obj->getName());
                        continue;
                    }
                    std::string OStr;
                    llvm::raw_string_ostream rso(OStr);
                    obj->print(rso);
                    sorted[FName][CBStr].insert(OStr);
                }
            }
        }
        for (auto &pair: sorted) {
            const std::string &FName = pair.first;
            dprint(FName);
            for (auto &pair1: pair.second) {
                const std::string &CBStr = pair1.first;
                dprint("- " << CBStr);
                for (const std::string &objStr: pair1.second) {
                    dprint("    - " << objStr);
                }
            }
        }
    }

    // Eval off the shelf pointer analysis
    // It uses either SVF or sea-dsa based on which wrapper has been passed
    void dataflowEval(Module &M, PointerAnalysis *pta, SeaDsa *SDSA) {
        assert((!pta || !SDSA) && "Only a single pointer analysis wrapper can be used");
        assert((pta || SDSA) && "At least a pointer analysis wrapper must be used");

        // keep track of all the object that may be passed from different callbases to the same function
        Function2CallBaseParamObjs ParamObjPerCallPerFunction;

        // collect all the objects accessed by fuctions given their calling context
        for (Function &F: M) {
            for (BasicBlock &BB: F) {
                for (Instruction &I: BB) {
                    // Search all call bases
                    if (CallBase * CB = dyn_cast<CallBase>(&I)) {

                        // Only if they represent direct calls to functions
                        if (CB->isInlineAsm()) continue;
                        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                        if (!Called || Called->isDeclaration() || isAvailableExternally(*Called) || Called->isIntrinsic()) continue;

                        // Collect the object the parameters may point-to
                        if (pta)
                            collectSVFParamObjects(pta, CB, ParamObjPerCallPerFunction[Called][CB]);
                        else if (SDSA)
                            collectSeaParamObjects(SDSA, CB, ParamObjPerCallPerFunction[Called][CB]);
                    }
                }
            }
        }

        // print all the object for each function callsite
        // dumpPtsObjects(ParamObjPerCallPerFunction);
    }

    // Visit `F` and all the functions called by `F`, adding them to `visitedFuncs`
    void visitCalledFunctions(Function* F, std::set<Function*> &visitedFuncs) {
        // bail out if already visited
        if (visitedFuncs.find(F) != visitedFuncs.end()) return;

        // insert into the visited functions
        visitedFuncs.insert(F);

        for (auto &BB : *F)
        for (auto &I : BB) {
            if (CallBase * CB = dyn_cast<CallBase>(&I)) {
                if (CB->isInlineAsm()) continue;

                Function *C = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                if (C) {
                    if (C->isDeclaration() || isAvailableExternally(*C) || C->isIntrinsic())
                    continue;
                    visitCalledFunctions(C, visitedFuncs);
                }
            }
        }
    }

    // Update info on the functions called
    void gatherCallInfo(Function *F) {
        for (BasicBlock &BB: *F) {
            for (Instruction &I : BB) {
                // Gather all call bases
                if (CallBase * CB = dyn_cast<CallBase>(&I)) {

                    // Only if they represent direct calls to functions
                    if (CB->isInlineAsm()) continue;
                    Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                    if (!Called || Called->isDeclaration() || isAvailableExternally(*Called) || Called->isIntrinsic()) continue;

                    // Update the info on number of times a function is called
                    CallsToFunction[Called]++;
                }
            }
        }
    }

    // Sometimes LLVM build the CallGraph withouth taking into considerations calls
    // that pass through a `bitcast` operation. We fix this here, revisiting the
    // functions and updating the CallGraph
    void fixCallGraph(Module &M, CallGraph *CG) {
        for (auto &F : M.getFunctionList()) {
            if (F.isDeclaration() || isAvailableExternally(F))
                continue;
            for(auto &BB: F) {
                for (auto &I : BB) {
                    if (CallBase * CB = dyn_cast<CallBase>(&I)) {
                        if (CB->isInlineAsm()) continue;

                        Function *Called = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                        if (!Called || Called->isDeclaration() || isAvailableExternally(*Called) || Called->isIntrinsic()) continue;

                        // If `Called` actually points to a function, but getCalledFunction
                        // returns null then we have spotted a missing function
                        if (CB->getCalledFunction() == nullptr) {
                            CallGraphNode *Node = CG->getOrInsertFunction(&F);
                            Node->addCalledFunction(CB, CG->getOrInsertFunction(Called));
                        }
                    }
                }
            }
        }
    }

    // Check if `F` just calls himself
    bool isSimplyRecursive(Function *F) {
        for (auto &BB : *F)
        for (auto &I : BB.instructionsWithoutDebug())
            if (auto *CB = dyn_cast<CallBase>(&I)) {
                Function *Callee = dyn_cast<Function>(CB->getCalledOperand()->stripPointerCasts());
                
                // Function calls itself
                if (Callee == F) {
                    return true;
                }
            }
        return false;
    }

    // Visit the `SCC` to gather the informations needed in `FunctionToSCC` and
    // `SCCFunctions`
    void collectSCC(CallGraphSCC &SCC) {
        std::set<Function *> Functions;
        for (CallGraphNode *I : SCC) {
            Functions.insert(I->getFunction());
        }

        // If the SCC contains multiple nodes we know there is recursion.
        if (Functions.size() != 1) {
            for (Function *F : Functions) {
                SCCFunctions.insert(F);
                assert(!F->doesNotRecurse());

                // A function should belong to a single SCC
                assert(FunctionToSCC.find(F) == FunctionToSCC.end());
                FunctionToSCC[F] = Functions;
            }
        // Take into account simple recursive functions
        } else {
            Function *F = *Functions.begin();
            if (F && isSimplyRecursive(F)) {
                SCCFunctions.insert(F);
                assert(!F->doesNotRecurse());

                assert(FunctionToSCC.find(F) == FunctionToSCC.end());
                FunctionToSCC[F] = Functions;
            }
        }
    }

    // Return true if `F` is part of a SCC
    bool isInSCC(Function *F) {
        return SCCFunctions.find(F) != SCCFunctions.end();
    }

  public:
    static char ID;
    PointerEvalPass() : ModulePass(ID) {}

    virtual bool runOnModule(Module &M) override {

        CallGraph *CG = &getAnalysis<CallGraphWrapperPass>().getCallGraph();

        // LLVM does not consider edges like `call (bitcast (func))` so insert them.
        // really llvm??
        fixCallGraph(M, CG);

        // Walk the callgraph in bottom-up SCC order.
        scc_iterator<CallGraph*> CGI = scc_begin(CG);
        
        CallGraphSCC CurSCC(*CG, &CGI);
        while (!CGI.isAtEnd()) {
            // Copy the current SCC and increment past it so that the pass can hack
            // on the SCC if it wants to without invalidating our iterator.
            const std::vector<CallGraphNode *> &NodeVec = *CGI;
            CurSCC.initialize(NodeVec);
            ++CGI;
        
            collectSCC(CurSCC);
        }

        // Gather initial info on functions
        std::set<Function*> visitedFuncs;
        for (Function &F : M) {
            if (F.isDeclaration() || isAvailableExternally(F))
                continue;

            // count all the calls in the function
            gatherCallInfo(&F);
        }

        std::chrono::steady_clock::time_point begin = std::chrono::steady_clock::now();
        std::string StrategyStr = "NONE";

        switch (Strategy)
        {

        case PointerStrategy::params: {
            paramsEval(M);
            StrategyStr = "params";
            break;
        }
        
        case PointerStrategy::dataflow: {
            SVFModule* svfModule = LLVMModuleSet::getLLVMModuleSet()->buildSVFModule(M);
            PAGBuilder builder;
            PAG* pag = builder.build(svfModule);

            FlowSensitive *pta = new FlowSensitive(pag);
            pta->analyze();
            dataflowEval(M, pta, nullptr);
            StrategyStr = "dataflow";
            break;
        }

        case PointerStrategy::dataflowSea: {
            SeaDsa *SDSA = new SeaDsa(this, &M); 
            dataflowEval(M, nullptr, SDSA);
            StrategyStr = "dataflowSea";
            break;
        }
        
        default:
            assert(false && "Clone strategy not supported");
            break;
        }

        dprint("---[ Ptr Eval Stats ]---");
        dprint("num ptrs:     " << nPointers);
        dprint("num objs:     " << nObjects);
        if (nPointers > 0) {
            std::stringstream sstream;
            sstream.setf(std::ios::fixed);
            sstream.precision(3);
            sstream << (((double) nObjects) / nPointers);

            dprint("ratio:        " << sstream.str());
        }

        std::chrono::steady_clock::time_point end = std::chrono::steady_clock::now();
        dprint("elapsed (ms): " << std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count());
        
        std::string result = StrategyStr + ": " + std::to_string(nPointers) + "|" + std::to_string(nObjects) + "|" + std::to_string(std::chrono::duration_cast<std::chrono::milliseconds>(end - begin).count()) + "|" + std::to_string(allCallBases.size()) + "|" + std::to_string(clonableCallBases.size()) + "|" + std::to_string(allFunctions.size()) + "|" + std::to_string(clonableFunctions.size()) + "|" + join(objectsPerPointer);
        if (OutFilename == "-") {
            outs() << result << "\n";
        } else {
            std::ofstream ofile;
            ofile.open(OutFilename, std::ios::out | std::ios::trunc);
            assert(ofile.is_open());

            ofile << result;
            ofile.flush();
            ofile.close();
        }

        return true;
    }

    void getAnalysisUsage(AnalysisUsage &AU) const override {
        AU.addRequired<CallGraphWrapperPass>();
        AU.addRequired<DominatorTreeWrapperPass>();
        AU.addRequired<PostDominatorTreeWrapperPass>();

        // dependencies for sea-dsa
        AU.addRequired<TargetLibraryInfoWrapperPass>();
        AU.addRequired<LoopInfoWrapperPass>();
    }
  };

}

char PointerEvalPass::ID = 0;
RegisterPass<PointerEvalPass> MP("ptr-eval", "Pointer Eval Pass");

// Register also seadsa::RemovePtrToInt so we can call it with opt
static llvm::RegisterPass<seadsa::RemovePtrToInt> RPI("remove-ptrtoint", "Remove ptrtoint instructions");