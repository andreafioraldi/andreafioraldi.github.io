#ifndef SEAA_H_
#define SEAA_H_

#include "llvm/ADT/DenseMap.h"
#include "llvm/ADT/DenseSet.h"
#include "llvm/ADT/SmallSet.h"
#include "llvm/ADT/SmallVector.h"
#include "llvm/Analysis/CallGraph.h"
#include "llvm/Analysis/MemoryBuiltins.h"
#include "llvm/Analysis/TargetLibraryInfo.h"
#include "llvm/IR/DataLayout.h"
#include "llvm/IR/IRBuilder.h"
#include "llvm/Pass.h"
#include "llvm/Support/CommandLine.h"
#include "llvm/Support/Debug.h"
#include "llvm/Transforms/Utils/BasicBlockUtils.h"
#include "llvm/Transforms/Utils/Cloning.h"
#include "llvm/Transforms/Utils/Local.h"

#include "seadsa/AllocWrapInfo.hh"
#include "seadsa/DsaLibFuncInfo.hh"
#include "seadsa/Global.hh"
#include "seadsa/support/RemovePtrToInt.hh"

using namespace llvm;

namespace {
class PTAWrapper {
public:
  virtual SmallVector<Value *, 8> getAllocSites(Value *V,
                                                const Function &F) = 0;
  virtual ~PTAWrapper() = default;
};

// A wrapper for seahorn dsa
class SeaDsa : public PTAWrapper {
  std::unique_ptr<seadsa::GlobalAnalysis> m_dsa;
  seadsa::Graph::SetFactory m_setFactory;

public:
  /// Returns a cell for \p ptr in \p fn
  const seadsa::Cell *getCell(const llvm::Value *ptr,
                              const llvm::Function &fn) {
    assert(ptr);
    assert(m_dsa);

    seadsa::Graph *g = nullptr;
    if (m_dsa->hasGraph(fn)) g = &m_dsa->getGraph(fn);
    if (!g) {
      // errs() << "SMC: Sea Dsa graph not found for " << fn.getName();
      return nullptr;
    }

    if (!(g->hasCell(*ptr))) {
      // errs() << "SMC: Sea Dsa node not found for " << *ptr;
      return nullptr;
    }

    const seadsa::Cell &c = g->getCell(*ptr);
    return &c;
  }

  SeaDsa(Pass* P, Module *M) {
    const DataLayout *m_dl = &M->getDataLayout();
    TargetLibraryInfoWrapperPass *m_tliWrapper = &P->getAnalysis<TargetLibraryInfoWrapperPass>();
    seadsa::AllocWrapInfo *m_allocInfo = new seadsa::AllocWrapInfo(m_tliWrapper);
    seadsa::DsaLibFuncInfo *m_dsaLibFuncInfo = new seadsa::DsaLibFuncInfo();
    m_allocInfo->initialize(*M, P);
    m_dsaLibFuncInfo->initialize(*M);
    auto &cg = P->getAnalysis<CallGraphWrapperPass>().getCallGraph();
    m_dsa.reset(new seadsa::BottomUpTopDownGlobalAnalysis(*m_dl, *m_tliWrapper, *m_allocInfo, *m_dsaLibFuncInfo, cg, m_setFactory));
    m_dsa->runOnModule(*M);
  }

  /// Returns points-to graph of \p F
  seadsa::Graph &getGraph(const Function &F) {
    seadsa::Graph *G = nullptr;
    if (m_dsa->hasGraph(F)) G = &m_dsa->getGraph(F);
    assert(G);
    return *G;
  }

  /// Returns Dsa node to which \p V points-to
  seadsa::Node &getNode(const Value &V, const Function &F) {
    auto *C = getCell(&V, F);
    assert(C);
    auto *N = C->getNode();
    assert(N);

    return *N;
  }

  /// Returns all allocation sites from which \p V might have originated in \p F
  SmallVector<Value *, 8> getAllocSites(Value *V, const Function &F) override {
    seadsa::Node &N = getNode(*V, F);

    SmallVector<Value *, 8> Sites;
    for (auto *S : N.getAllocSites()) {
      // XXX stripping declarations seems too much since some might be legal
      // allocation functions
      // XXX At least use attributes and TLI
      if (auto *GV = dyn_cast<const GlobalValue>(S))
        if (GV->isDeclaration())
          continue;

      Sites.push_back(const_cast<Value *>(S));
    }

    return Sites;
  }

  void viewGraph(const Function &F) { 
    seadsa::Graph *G = nullptr;
    if (m_dsa->hasGraph(F)) G = &m_dsa->getGraph(F);
    assert(G);
    G->viewGraph();
  }
};
}
#endif /* SEAA_H_ */
