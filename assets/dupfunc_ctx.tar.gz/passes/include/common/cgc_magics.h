#ifndef _CGC_MAGICS_H
#define _CGC_MAGICS_H

#define CGC_ROOT_ATTR "cgc_root"
#define CGC_CLONE_CALL_ATTR "cgc_clone_call"
#define CGC_CLONE_PRIORITY "cgc_clone_priority"
#define CGC_CLONE_NEVER "cgc_clone_never"

#endif /* _CGC_MAGICS_H */
