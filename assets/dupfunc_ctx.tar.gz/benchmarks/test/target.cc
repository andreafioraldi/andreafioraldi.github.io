// Copyright 2020 Google LLC
//
// Licensed under the Apache License, Version 2.0 (the "License");
// you may not use this file except in compliance with the License.
// You may obtain a copy of the License at
//
//      http://www.apache.org/licenses/LICENSE-2.0
//
// Unless required by applicable law or agreed to in writing, software
// distributed under the License is distributed on an "AS IS" BASIS,
// WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
// See the License for the specific language governing permissions and
// limitations under the License.

#include <string>
#include <vector>

void ignore (void * ctx, const char * msg, ...) {}
void a();
void a1();

__attribute_noinline__ void e() {
  puts("B");
}

__attribute_noinline__ void d() {
  puts("A");
  e();
  a();
  a1();
}

__attribute_noinline__ void c() {
  puts("A");
  d();
}
__attribute_noinline__ void b() {
  puts("A");
  c();
}
__attribute_noinline__ void a() {
  puts("A");
  b();
}

__attribute_noinline__ void d1() {
  puts("A");
  a1();
  a();
}

__attribute_noinline__ void c1() {
  puts("A");
  d1();
}
__attribute_noinline__ void b1() {
  puts("A");
  c1();
}
__attribute_noinline__ void a1() {
  puts("A");
  b1();
}

extern "C" int LLVMFuzzerTestOneInput(const uint8_t *data, size_t size) {
  a();
  a();
  a1();
  return 0;
}
