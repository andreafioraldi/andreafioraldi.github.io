class Foo {
public:
  virtual int function() = 0;
};

class Bar: public Foo {
public:
  // int function() {return 123;}
  int function();
};

int Bar::function() {
  return 123;
}

int main() {
    Bar bar;
    return bar.function();
}

// @_ZTV3Bar = dso_local constant { { [3 x i8*] }, [40 x i8] } { { [3 x i8*] } { [3 x i8*] [i8* null, i8* bitcast ({ { i8*, i8*, i8* }, [40 x i8] }* @_ZTI3Bar to i8*), i8* bitcast (i32 (%class.Bar*)* @_ZN3Bar8functionEv to i8*)] }, [40 x i8] zeroinitializer }, align 32
// @_ZTV3Bar = linkonce_odr dso_local unnamed_addr constant { [3 x i8*] } { [3 x i8*] [i8* null, i8* bitcast ({ i8*, i8*, i8* }* @_ZTI3Bar to i8*), i8* bitcast (i32 (%class.Bar*)* @_ZN3Bar8functionEv to i8*)] }, comdat, align 8, !type !0, !type !1, !type !2, !type !3