#!/bin/bash

set -e

ROOT_DIR="../.."

# setup llvm env variables
cd ../..
. ./setup.sh
cd - > /dev/null

DIR=`pwd`
cd $ROOT_DIR/passes
make install || exit 1
cd $DIR

BENCH="zlib_uncompress_fuzzer"

git clone --depth 1 -b develop https://github.com/madler/zlib.git || true
cd zlib
export LLVM_BITCODE_GENERATION_FLAGS="-flto"
export CFLAGS="-flto -fembed-bitcode"
export CXXFLAGS="-flto -fembed-bitcode"
export LDFLAGS="-fuse-ld=lld -flto=full -Wl,-mllvm,-lto-embed-bitcode -Wl,--lto-O0"
export RANLIB=llvm-ranlib

CC=clang CXX=clang++  ./configure
make clean
make -j1 all
# get-bc -b -o libz.bc libz.a
exit 2
cd ..

clang++ -O1 -flto -c -o $BENCH.base.bc $BENCH.cc
llvm-link -o $BENCH.linked.bc $BENCH.base.bc zlib/libz.bc
../opt -dump-call-tree -call-tree-start="LLVMFuzzerTestOneInput" -dump-tree-file='call-tree.log' -o /dev/null $BENCH.linked.bc
../opt -internalize -internalize-public-api-file='call-tree.log' -globaldce -o $BENCH.linked_int.bc $BENCH.linked.bc
# ../opt -icp -icp-fallback -icp-type -icp-type-opaque-ptrs=0 -icp-alias -stat=0 -ander -modelConsts -o $BENCH.icp.bc $BENCH.linked_int.bc
../opt -cgc -cgc-funcs='LLVMFuzzerTestOneInput' -cgc-clone-prefix='' -dump-call-tree -call-tree-start="LLVMFuzzerTestOneInput" -dump-tree-file='call-tree.log' -o $BENCH.cgc0.bc $BENCH.linked_int.bc
../opt -internalize -internalize-public-api-file='call-tree.log' -globaldce -o $BENCH.cgc.bc $BENCH.cgc0.bc
../opt -func-stats $BENCH.linked_int.bc -o /dev/null
../opt -func-stats $BENCH.cgc.bc -o /dev/null

clang++ -O1 ../driver.cc $BENCH.cgc.bc -o zlib.out 