#!/bin/bash

set -e
set -x

ROOT_DIR="../.."

# setup llvm env variables
if [ -z "${LLVM_DIR}" ]; then 

  echo "[ ] retrieving the LLVM directory..."

  if [ -z "${LLVM_CONFIG}" ]; then 
      export LLVM_CONFIG='llvm-config'
  fi

  export LLVM_VER="$($LLVM_CONFIG --version 2>/dev/null | sed 's/git//')"
  if [ "$LLVM_VER" = "" ]; then
    echo "[!] llvm-config not found!"
    exit 1
  fi

  echo "[+] using LLVM $LLVM_VER"

  export PATH="$($LLVM_CONFIG --bindir)/bin:$SVF_HOME/Debug-build/bin:$PATH"
  export LLVM_DIR="$($LLVM_CONFIG --prefix)"

else

  export PATH="$LLVM_DIR/bin:$SVF_HOME/Debug-build/bin:$PATH"

fi

echo "[+] the LLVM directory is $LLVM_DIR"
export LLVM_COMPILER_PATH=$LLVM_DIR/bin

DIR=`pwd`
cd $ROOT_DIR/passes
make install || exit 1
cd $DIR

export LLVM_BITCODE_GENERATION_FLAGS="-flto"
BENCH="target"

# export CC=gclang 
# export CXX=gclang++ 
# export CCLD=gclang++
# export LD=gclang++

export FUZZ_TARGET='libproj.out'


# if [[ -d PROJ ]]; then
#   echo "[+] PROJ already present"
# else
    git clone https://github.com/OSGeo/PROJ || true

    cd PROJ
    git checkout d00501750b210a73f9fb107ac97a683d4e3d8e7a
    ./autogen.sh
    CC=gclang CXX=gclang++ ./configure
    make clean all

    get-bc -b -o ./libproj.bc src/.libs/libproj.a
    cd ..
# fi

"$LLVM_COMPILER_PATH/clang++" -O1 -flto -I PROJ/src -c -o $BENCH.base.bc PROJ/test/fuzzers/standard_fuzzer.cpp
"$LLVM_COMPILER_PATH/llvm-link" -o $BENCH.linked.bc $BENCH.base.bc PROJ/libproj.bc
../opt -dump-call-tree -call-tree-start="LLVMFuzzerTestOneInput" -dump-tree-file='call-tree.log' -o /dev/null $BENCH.linked.bc
../opt -internalize -internalize-public-api-file='call-tree.log' -globaldce -o $BENCH.linked_int.bc $BENCH.linked.bc
# ../opt -icp -icp-fallback -icp-type -icp-type-opaque-ptrs=0 -icp-alias -stat=0 -ander -modelConsts -o $BENCH.icp.bc $BENCH.linked_int.bc
../opt -cgc -cgc-funcs='LLVMFuzzerTestOneInput' -cgc-clone-prefix='' -dump-call-tree -call-tree-start="LLVMFuzzerTestOneInput" -dump-tree-file='call-tree.log' -o $BENCH.cgc0.bc $BENCH.linked_int.bc
../opt -internalize -internalize-public-api-file='call-tree.log' -globaldce -o $BENCH.cgc.bc $BENCH.cgc0.bc
../opt -func-stats $BENCH.linked_int.bc -o /dev/null
../opt -func-stats $BENCH.cgc.bc -o /dev/null

"$LLVM_COMPILER_PATH/clang++" -O1 ../driver.cc $BENCH.cgc.bc PROJ/src/.libs/libproj.a -lpthread -o libproj.out 

