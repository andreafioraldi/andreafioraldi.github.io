#!/usr/bin/env python3

import re
import sys
import networkx as nx
from collections import defaultdict 
import matplotlib.pyplot as plt


G = nx.MultiDiGraph()
G2 = nx.MultiDiGraph()

def parse_cg(G, lines):
    fn = None
    for l in lines:
        m = re.match("Call graph node for function: '(.+?)'", l)
        if m:
            fn = m.group(1)
            G.add_node(fn)
        m = re.match(".* calls function '(.+?)'", l)
        if m:
            G.add_edge(fn, m.group(1))

if len(sys.argv) > 1:
    with open(sys.argv[1]) as f:
        parse_cg(G, f.readlines())
else:
    parse_cg(G, sys.stdin.readlines())


funcToSCC = dict()
cgcFunctionSet = list()

for scc in nx.strongly_connected_components(G):
    if len(scc) > 1:
        for funcSCC in scc:
            assert(funcSCC not in funcToSCC)
            funcToSCC[funcSCC] = scc
    else:
        if None not in scc:
            funcSCC = next(iter(scc))
            # if is recursive simply
            if G.has_edge(funcSCC, funcSCC):
                assert(funcSCC not in funcToSCC)
                funcToSCC[funcSCC] = scc


DEBUG = False
def dbg_print(s):
    if DEBUG:
        print(s)

def isClone(func):
    return False

clones = 0
def trackClone(func):
    global clones 
    clones += 1
    sys.stdout.write("\r" + str(clones) + " - " + str(len(cgcFunctionSet)))
    dbg_print("    " + func)

def addSCCClone(func):
    dbg_print("addSCC: " + func)
    scc = funcToSCC[func]
    sccClones = set()
    for funcSCC in scc:
        trackClone(funcSCC)
        sccClones.add(funcSCC)

    for SCCclone in scc:
        for _, SCCSucc in G.out_edges(SCCclone):
            if SCCSucc in sccClones:
                # rewire
                continue
            else:
                addFunctionClone(SCCSucc)
                sccClones.add(SCCSucc)
                # pass
    dbg_print("retSCC: " + func)


def addFunctionClone(func):
    assert not isClone(func)

    # if part of an SCC
    if func in funcToSCC:
        addSCCClone(func)
        return

    dbg_print("addFunc: " + func)
    # clone single function
    trackClone(func)

    cgcFunctionSet.append(func)
    dbg_print("retFunc: " + func)


def cgc(func):
    for _, callee in G.out_edges(func):
        addFunctionClone(callee)

assert(G.has_node("LLVMFuzzerTestOneInput"))
cgcFunctionSet.append("LLVMFuzzerTestOneInput")

while len(cgcFunctionSet):
    curr = cgcFunctionSet.pop()
    dbg_print(curr)
    cgc(curr)
print("")
print("Total Clones: " + str(clones))