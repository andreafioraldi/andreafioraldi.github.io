#!/bin/bash -eu
#!/bin/bash

set -e
set -x

ROOT_DIR="../.."

# setup llvm env variables
if [ -z "${LLVM_DIR}" ]; then 

  echo "[ ] retrieving the LLVM directory..."

  if [ -z "${LLVM_CONFIG}" ]; then 
      export LLVM_CONFIG='llvm-config'
  fi

  export LLVM_VER="$($LLVM_CONFIG --version 2>/dev/null | sed 's/git//')"
  if [ "$LLVM_VER" = "" ]; then
    echo "[!] llvm-config not found!"
    exit 1
  fi

  echo "[+] using LLVM $LLVM_VER"

  export PATH="$($LLVM_CONFIG --bindir)/bin:$SVF_HOME/Debug-build/bin:$PATH"
  export LLVM_DIR="$($LLVM_CONFIG --prefix)"

else

  export PATH="$LLVM_DIR/bin:$SVF_HOME/Debug-build/bin:$PATH"

fi

echo "[+] the LLVM directory is $LLVM_DIR"
export LLVM_COMPILER_PATH=$LLVM_DIR/bin

DIR=`pwd`
cd $ROOT_DIR/passes
make install || exit 1
cd $DIR

# export CC=gclang 
# export CXX=gclang++ 
# export CCLD=gclang++
# export LD=gclang++

export CC=/home/one/Documents/University/PhD/projects/AFLChen/bin/wrap-gclang 
export CXX=/home/one/Documents/University/PhD/projects/AFLChen/bin/wrap-gclang++ 
export CXXFLAGS="-fsanitize=address -fsanitize=array-bounds,bool,builtin,enum,float-divide-by-zero,function,integer-divide-by-zero,null,object-size,return,returns-nonnull-attribute,shift,signed-integer-overflow,unreachable,vla-bound,vptr -fsanitize-coverage=trace-pc-guard -stdlib=libc++ -O1"
export RANLIB='llvm-ranlib'
export AR='llvm-ar'
export AS='llvm-as'

export SRC=.
export OUT=out
export FUZZ_TARGET="$OUT/stbi_read_fuzzer"

export WRAP_GCLANG_DEBUG=1
export NO_INTERNALIZE=1

sed '2d' $SRC/stb/tests/stb_png_read_fuzzer.cpp > $SRC/stb/tests/stbi_read_fuzzer.c

$CXX $CXXFLAGS -std=c++11 -I. \
    $SRC/stb/tests/stbi_read_fuzzer.c \
    -o $OUT/stbi_read_fuzzer ../driver.cc

# find $SRC/stb/tests/pngsuite -name "*.png" | \
#      xargs zip $OUT/stb_png_read_fuzzer_seed_corpus.zip

# cp $SRC/stb/tests/stb_png.dict $OUT/stb_png_read_fuzzer.dict

# tar xvzf $SRC/stb/jpg.tar.gz --directory $SRC/stb/tests
# tar xvzf $SRC/stb/gif.tar.gz --directory $SRC/stb/tests

# find $SRC/stb/tests -name "*.png" -o -name "*.jpg" -o -name ".gif" | \
#      xargs zip $OUT/stbi_read_fuzzer_seed_corpus.zip

# echo "" >> $SRC/stb/tests/gif.dict
# cat $SRC/stb/tests/gif.dict $SRC/stb/tests/stb_png.dict > $OUT/stbi_read_fuzzer.dict
