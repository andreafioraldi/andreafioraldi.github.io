struct A {
  void f(...);
};

struct B : virtual A {
  void b();
  void f(...);
};

void B::f(...) {}