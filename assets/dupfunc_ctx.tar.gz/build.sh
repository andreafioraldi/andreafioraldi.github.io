#!/bin/bash

./install_svf.sh
./install_seadsa.sh
make -C passes

cd bin && clang -c ../aflpp-link-safe.c
