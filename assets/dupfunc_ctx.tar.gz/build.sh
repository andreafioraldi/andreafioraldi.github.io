#!/bin/bash

./install_svf.sh
make -C passes

cd bin && $CC -c ../aflpp-link-safe.c
