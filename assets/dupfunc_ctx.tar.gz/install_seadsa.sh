#!/bin/bash

set -e
export MAKEFLAGS="-j $(grep -c ^processor /proc/cpuinfo)"

if [ -z "${LLVM_DIR}" ]; then 

  echo "[ ] retrieving the LLVM directory..."

  if [ -z "${LLVM_CONFIG}" ]; then 
      export LLVM_CONFIG='llvm-config'
  fi

  export LLVM_VER="$($LLVM_CONFIG --version 2>/dev/null | sed 's/git//')"
  if [ "$LLVM_VER" = "" ]; then
    echo "[!] llvm-config not found!"
    exit 1
  fi

  echo "[+] using LLVM $LLVM_VER"

  export PATH="$($LLVM_CONFIG --bindir)/bin:$PATH"
  export LLVM_DIR="$($LLVM_CONFIG --prefix)"

else

  export PATH="$LLVM_DIR/bin:$PATH"

fi

echo "[+] the LLVM directory is $LLVM_DIR"

#
# sea-dsa
#
echo "[ ] preparing sea-dsa..."

if [[ -d sea-dsa ]]; then
  echo "[!] the sea-dsa directory already exists"
  cd sea-dsa
else
  git clone https://github.com/seahorn/sea-dsa.git -b dev10
  cd sea-dsa
  git checkout 594279ef14e5dc6b70322912988c98bfce7b7a10
fi

echo "[+] sea-dsa ready"

echo "[ ] compiling sea-dsa..."
mkdir build && cd build
cmake -DCMAKE_C_COMPILER=clang -DCMAKE_CXX_COMPILER=clang++ -DCMAKE_VERBOSE_MAKEFILE:BOOL=ON -DCMAKE_INSTALL_PREFIX=run -DLLVM_DIR=$LLVM_DIR/share/llvm/cmake ..
cmake --build . --target install
echo "[+] all done, goodbye!"
