__attribute__((weak)) unsigned int * __afl_fuzz_len;
__attribute__((weak)) unsigned char *__afl_fuzz_ptr;
__attribute__((weak)) int __afl_persistent_loop(unsigned int x) { return 0; }
__attribute__((weak)) void __afl_manual_init() {}
